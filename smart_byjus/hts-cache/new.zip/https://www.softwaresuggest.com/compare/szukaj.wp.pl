
<!DOCTYPE html>
<html lang="en">
<head>
<style>.async-hide { opacity: 0 !important} </style>
<script>(function(a,s,y,n,c,h,i,d,e){s.className+=' '+y;h.start=1*new Date;
h.end=i=function(){s.className=s.className.replace(RegExp(' ?'+y),'')};
(a[n]=a[n]||[]).hide=h;setTimeout(function(){i();h.end=null},c);h.timeout=c;
})(window,document.documentElement,'async-hide','dataLayer',0,
{'GTM-PS4MFCR':true});</script>

<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta http-equiv="Content-Security-Policy" content="block-all-mixed-content">
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0">
<script src="https://www.googleoptimize.com/optimize.js?id=GTM-PS4MFCR"></script>
<script type="text/javascript" src="https://www.softwaresuggest.com/assets2/js/lazysizes.min.js" async=""></script>
<link rel="stylesheet" type="text/css" href="https://www.softwaresuggest.com/assets2/css/newcss/other.css?v=0.91" />

<style type="text/css">
/*#This css is used in html which inserted from data entry operators*/
/*Cat Description ul li*/
.cat_temp_div{padding: 0;}.cat_temp_div .cat_temp_div2 .cat_temp_div3{border:2px solid #ddd;margin:0 auto}.cat_temp_div .cat_temp_div2 .cat_temp_div3 h4{font-size:18px;color:#fff;background-color:#266499!important;font-weight:500;text-align:center;margin:0}.cat_temp_div .cat_temp_div2 .cat_temp_div3 .cat_temp_div4 ul{margin:0;padding:0;text-align:center;list-style-type:none}.cat_temp_div .cat_temp_div2 .cat_temp_div3 .cat_temp_div4 ul li:nth-child(odd){background:#e9f0f5}.cat_temp_div .cat_temp_div2 .cat_temp_div3 .cat_temp_div4 ul li span{color:#266499;font-weight:500}
/*End Cat Description ul li*/
/*Cat Description Table*/
.cm_table_client_logo_section{border-collapse:collapse;width:100%}.cm_table_tr_soft_name,.cm_table_tr_soft_name td{border:1px solid #c3c3c3}.cm_table_client_logo th,.cm_table_tr_soft_name td,.cm_table_tr_soft_name th{width:25%;height:60px;text-align:center;font-weight:500}.cm_table_client_logo{width:100%}.cm_table_client_logo_th_div{width:100px;height:60px}.cm_table_client_logo_th_div img{max-width:100%;max-height:100%}.cm_table_tr_soft_name .cm_table_empty_sec{border:none}.cm_table_custom_border{border-top:1px solid #c3c3c3;border-right:1px solid #c3c3c3;border-left:1px solid #c3c3c3;background-color:#54b0e6;color:#fff;font-weight:400;font-size:15px;font-family:sans-serif;height:45px}.cm_table_tr_soft_name .cm_table_m_icon_cancel,.cm_table_tr_soft_name .cm_table_m_icon_checak{line-height:2;font-size:30px;font-family:'Material Icons'!important}.cm_table_m_icon_checak{color:#77d33c}.cm_table_m_icon_cancel{color:#999}
.fa.fa-star,.fa.fa-star-half-o,.fa.fa-star-o,.star_line_hight .star_value,.s0,.s1,.s15,.s2,.s25,.s3,.s35,.s4,.s45,.s5:before,.br-theme-fontawesome-stars .br-widget a.br-selected:after,.br-active:after,.material-icons.star{color: #43a047 !important;}
/*End Cat Description Table*/
</style>

<meta name="robots" content="all" />

<title>Softwaresuggest - Error Site</title>


<meta name="twitter:card" content="" />
<meta name="twitter:site" content="" />
<meta name="twitter:creator" content="" />
<meta name="twitter:image" content="" />

<meta property="og:type" content="" />
<meta property="og:title" content="" />
<meta property="og:url" content="" />
<meta property="og:description" content="" />
<meta property="og:image" content="" />
<meta property="og:image:secure_url" content="" />

<link rel="shortcut icon" href="https://www.softwaresuggest.com/assets2/img/fevicon.png" />
<script>var cat_id="";(function(d,e,j,h,f,c,b){d.GoogleAnalyticsObject=f;d[f]=d[f]||function(){(d[f].q=d[f].q||[]).push(arguments)},d[f].l=1*new Date();c=e.createElement(j),b=e.getElementsByTagName(j)[0];c.async=1;c.src=h;b.parentNode.insertBefore(c,b)})(window,document,"script","//www.google-analytics.com/analytics.js","ga");ga("create","UA-47218037-1","www.softwaresuggest.com",{siteSpeedSampleRate:100}); ga("send","pageview");</script>
<script type="text/javascript">(function(){var a="https:"==document.location.protocol;var b=(a?"https:":"http:")+"//www.googletagservices.com/tag/js/gpt.js";document.write('<script src="'+b+'"><\/script>')})();</script>
<script type="text/javascript">googletag.cmd.push(function(){googletag.pubads().setTargeting("pageid","-software");googletag.pubads().collapseEmptyDivs();googletag.pubads().enableSyncRendering();googletag.enableServices()});</script>
<script async='async' src='https://www.googletagservices.com/tag/js/gpt.js'></script>
<script>

var googletag = googletag || {};

googletag.cmd = googletag.cmd || [];

</script>
<script>

googletag.cmd.push(function() {

googletag.defineSlot('/58135396/Review_Code', [728, 90], 'div-gpt-ad-1550663098870-0').addService(googletag.pubads());

googletag.pubads().enableSingleRequest();

googletag.enableServices();

});

</script>

<script async src="https://www.googletagmanager.com/gtag/js?id=AW-665064630"></script>
<script>window.dataLayer = window.dataLayer || [];function gtag(){dataLayer.push(arguments);}gtag('js', new Date());gtag('config', 'AW-665064630');</script>

<script src="https://cdn.pagesense.io/js/callhippo/00f94549c9564cebb1a1db0bd87cad52.js"></script>
</head>
<body class="mdl-demo mdl-color--grey-100 mdl-color-text--black-500 mdl-base new_body_color_cat">
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-WQDBJVZ" height=0 width=0 style=display:none;visibility:hidden></iframe></noscript>
<div class="mdl-layout mdl-layout--fixed-header mdl-layout--fixed-tabs">
<style type="text/css">
/*new searchbar css*/
.autocomplete-suggestions { border: 1px solid #999; background: #FFF; overflow: auto;width: 260px !important; }
.autocomplete-suggestion {white-space: nowrap; overflow: hidden; }
.autocomplete-suggestions strong { font-weight: normal; color: #3399FF; }
.autocomplete-group strong { display: block; border-bottom: 1px solid #000; }
.suggestions_global_search {
    position: fixed !important;
    top: 50px !important;
    max-height: unset !important;
    border-width: 1px;
    border-style: solid;
    border-color: rgb(238, 238, 238);
    border-image: initial;
    background: rgb(255, 255, 255);
    border-radius: 4px;
    overflow: auto;
    box-shadow: 0 10px 20px rgba(0,0,0,.19), 0 6px 6px rgba(0,0,0,.23);
    -webkit-box-shadow: 0 10px 20px rgba(0,0,0,.19), 0 6px 6px rgba(0,0,0,.23);
    -moz-box-shadow: 0 10px 20px rgba(0,0,0,.19),0 6px 6px rgba(0,0,0,.23);
    margin-top: 4px;
}
.suggestions_global_search .autocomplete-suggestion a {
    padding: 4px 24px;
    color: #333333;
    font-size: 14px;
    cursor: pointer;
    display: block;
    font-weight: 400;
}
.suggestions_global_search .autocomplete-group {
    padding: 5px 11px;
    color: #3a3a3a;
    border-radius: 3px;
    margin-bottom: 0;
    font-weight: 600;
}
.search_loader_homepage {
    background-image: url('https://www.softwaresuggest.com/assets2/desktop_view/assets/icon/ajax-loader.svg');
    width: 16px;
    height: 16px;
    background-size: cover;
    position: absolute;
    right: 35px;
    top: 15px;
    display: none;
}
.autocomplete-no-suggestion {
	font-size: 15px;
    line-height: 1.7;
    padding: 0 10px;
}
@media only screen and (max-width: 1024px) {
	.autocomplete-suggestions { width: 100% !important; }
}
/*new searchbar css end*/
.sslogo_div{display:flex;justify-content:center;align-items:center;flex-direction:column}.sslogo{width:180px}.sshiring{font-size:12.5px;background:#ff9800;padding:4px 0;color:#fff;font-weight:500;letter-spacing:.5px;border-radius:3px;position:absolute;left:185px;width:93px;line-height:normal;top:3px;text-align:center;text-shadow:1px 1px rgba(0,0,0,.3)}.sshiring:hover{background-color:#fff;color:#005a8c;text-shadow:unset}@media only screen and (max-width:1024px){.sshiring,.sslogo{margin-right:10px}.sslogo{width:80px}.sshiring{position:unset;margin-top:3px;width:90px;font-size:12px}}@media only screen and (max-width:767px){.sshiring{font-size:10px}}.cns_sidetop_link_outer{display:flex;align-items:center}
.mobileapp_android_icon{
	color: #a4c639;
}
.mobileapp_apple_icon{
	color: #7d7d7d;
}
.drop ul li {
	padding: 5px 0 !important;
}
@media only screen and (max-width: 1024px) {
.mobileapp_android_icon , .mobileapp_apple_icon{	
   	font-size: 16px;
   	margin-left: 3px;
}
</style>
<style type="text/css">
		.home_drop_tab {
		    padding: 0 16px 8px;
		}
		#service_tab_ul {
		    width: 420px;
		    left: 0;
		    padding: 0;
		    top: 3em;
		}
		#service_tab_ul .triangle::before {
		    top: -9px;
		    left: 98%;
		}
		.service_menu_title_div {
		    margin-bottom: 0;
		}
		#service_tab_ul li a.service_menu_title {
		    font-size: 13px !important;
		    color: #135893;
		    text-decoration: underline !important;
		    font-weight: 600;
		}
		#cat_sub_menu1 li a.service_menu_title{
			font-size: 13px !important;
			font-weight: 600;
		}
		.dropulmenu li a.software_menu_title{
			font-size: 13px !important;
			text-decoration: underline !important;
			color: #135893 !important;
			font-weight: 600;
		}
		.service_menu_title_li{
			padding-bottom: 0 !important;
		}
		#service_tab_ul li a {
		    font-size: 13px !important;
		}
		.cat_list_title_color {
		    padding: 7px 0!important;
		}
		.head_top_btn{
			text-transform: capitalize;
		}
		.software_menu_title_div{
		    margin-top: -8px;
    		margin-bottom: -4px;
		}
	</style>
<header class="mdl-layout__header mdl-cell--hide-phone mdl-cell--hide-tablet background_new_color chsticky">
<div class="mdl-layout__header-row header-row">
<div class="mdl-layout-title">
<a href="https://www.softwaresuggest.com/"><img class="sslogo" src="https://d1myhw8pp24x4f.cloudfront.net/logo/sswhite.svg" style="padding-left:40px;" alt="SoftwareSuggest"></a>
</div>
<div class="mdl-layout-spacer"></div>
<li class="drop drop-category cstyle_same">
<a class="mdl-navigation__link mdl-layout--large-screen-only cat_link">Software Categories <i class="material-icons">keyboard_arrow_down</i></a>
<ul>
<div class="triangle"></div>
<div class="mdl-grid">
<div class="mdl-cell mdl-cell--12-col software_menu_title_div">
<li><a class="software_menu_title" href="https://www.softwaresuggest.com/" onclick="ga('send','event','N-SoftwareHome','RCB-Header','RCB-Header');">Software Hub</a></li>
</div>
<div class="mdl-cell mdl-cell--3-col">
<li class="cat_list_title_color"><b>Accounting & Finance</b></li>
<li><a class="sub_category" href="https://www.softwaresuggest.com/accounting-software" target="_self">Accounting Software</a></li>
<li><a class="sub_category" href="https://www.softwaresuggest.com/personal-finance-software" target="_self">Personal Finance</a></li>
<li><a class="sub_category" href="https://www.softwaresuggest.com/online-accounting-software" target="_self">Online Accounting </a></li>
 <li><a class="sub_category" href="https://www.softwaresuggest.com/financial-management-software" target="_self">Finance Management</a></li>
<li><a class="sub_category" href="https://www.softwaresuggest.com/fixed-asset-accounting-software" target="_self">Fixed Asset Accounting</a></li>
<li><a class="sub_category" href="https://www.softwaresuggest.com/gst-software" target="_self">GST Software</a></li>
<li class="cat_list_title_color"><a href="https://www.softwaresuggest.com/billing-invoicing-software" target="_self"><b>Billing & Invoicing</b> </a></li>
<li class="cat_list_title_color"> <a href="https://www.softwaresuggest.com/cloud-telephony-ivrs-software" target="_self"><b>Cloud Telephony &amp; IVRS</b></a></li>
<li class="cat_list_title_color"><b>Customer & Sales Management <i class="fa fa-caret-down" aria-hidden="true"></i></b></li>
<li><a class="sub_category" href="https://www.softwaresuggest.com/crm-software" target="_self">CRM</a></li>
<li><a class="sub_category" href="https://www.softwaresuggest.com/lead-management-system" target="_self">Lead Management</a></li>
<li><a class="sub_category" href="https://www.softwaresuggest.com/order-management-software" target="_self">Order Management</a></li>
<li><a class="sub_category" href="https://www.softwaresuggest.com/sfa-sales-force-automation-software" target="_self">SFA</a></li>

</div>
<div class="mdl-cell mdl-cell--3-col">
<li class="cat_list_title_color"> <a href="https://www.softwaresuggest.com/ecommerce-platform-software" target="_self"><b>Ecommerce Software </b></a></li>
<li class="cat_list_title_color"><b>Education & Campus Management <i class="fa fa-caret-down" aria-hidden="true"></i></b></li>
<li><a class="sub_category" href="https://www.softwaresuggest.com/school-management-software" target="_self">School Management</a></li>
<li><a class="sub_category" href="https://www.softwaresuggest.com/colleges-universities-software" target="_self">Colleges & Universities</a></li>
<li><a class="sub_category" href="https://www.softwaresuggest.com/campus-management-software" target="_self">Campus Management</a></li>
<li><a class="sub_category" href="https://www.softwaresuggest.com/library-management-software" target="_self">Library Management</a></li>
<li class="cat_list_title_color"><a href="https://www.softwaresuggest.com/erp-software" target="_self"><b>Enterprise Resource Planning</b></a></li>
<li class="cat_list_title_color"><b>Human Resource Management <i class="fa fa-caret-down" aria-hidden="true"></i></b></li>
<li><a class="sub_category" href="https://www.softwaresuggest.com/hr-software" target="_self">HR Software</a></li>
<li><a class="sub_category" href="https://www.softwaresuggest.com/payroll-software" target="_self">Payroll Software</a></li>
<li><a class="sub_category" href="https://www.softwaresuggest.com/payroll-outsourcing-services" target="_self">Payroll Outsourcing</a></li>
<li><a class="sub_category" href="https://www.softwaresuggest.com/attendance-management-software" target="_self">Attendance Management</a></li>
<li><a class="sub_category" href="https://www.softwaresuggest.com/time-management-software" target="_self">Time Management</a></li>
<li><a class="sub_category" href="https://www.softwaresuggest.com/time-tracking-software" target="_self">Time Tracking Software</a></li>
<li><a class="sub_category" href="https://www.softwaresuggest.com/recruiting-software" target="_self">Recruiting Software</a></li>
<li><a class="sub_category" href="https://www.softwaresuggest.com/performance-management-system" target="_self">Performance Management</a></li>
<li class="cat_list_title_color"><b>Hospital, Clinic & Lab Management<i class="fa fa-caret-down" aria-hidden="true"></i></b></li>
<li><a class="sub_category" href="https://www.softwaresuggest.com/emr-clinic-management-software" target="_self">EMR & Clinic Management</a></li>
<li><a class="sub_category" href="https://www.softwaresuggest.com/hospital-management-software" target="_self">Hospital Management</a></li>
</div>
<div class="mdl-cell mdl-cell--3-col">
<li><a class="sub_category" href="https://www.softwaresuggest.com/lab-management-software" target="_self">Lab Management</a></li>
<li><a class="sub_category" href="https://www.softwaresuggest.com/patient-management-software" target="_self">Patient Management</a></li>
<li class="cat_list_title_color"> <a href="https://www.softwaresuggest.com/housing-society-apartments-software" target="_self"><b>Housing Society & Apartments</b></a></li>
<li class="cat_list_title_color"><b>Hotel, Restaurant & Salon<i class="fa fa-caret-down" aria-hidden="true"></i></b></li>
<li><a class="sub_category" href="https://www.softwaresuggest.com/hms-hotel-management-software" target="_self">Hotel Management</a></li>
<li><a class="sub_category" href="https://www.softwaresuggest.com/restaurant-bar-software" target="_self">Restaurant & Bar</a></li>
<li><a class="sub_category" href="https://www.softwaresuggest.com/reservation-booking-software" target="_self">Reservation & Booking</a></li>
<li><a class="sub_category" href="https://www.softwaresuggest.com/spa-salon-software" target="_self">Spa and Salon</a></li>
<li><a class="sub_category" href="https://www.softwaresuggest.com/property-management-software" target="_self">Property Management</a></li>
<li class="cat_list_title_color"> <a href="https://www.softwaresuggest.com/inventory-management-software" target="_self"><b>Inventory & Stock Management</b></a></li>
<li class="cat_list_title_color"><b>Pharmaceutical<i class="fa fa-caret-down" aria-hidden="true"></i></b></li>
<li><a class="sub_category" href="https://www.softwaresuggest.com/medical-store-software" target="_self">Medical Store</a></li>
<li><a class="sub_category" href="https://www.softwaresuggest.com/mr-reporting-software" target="_self">MR Reporting</a></li>
<li><a class="sub_category" href="https://www.softwaresuggest.com/pharmaceutical-industry-software" target="_self">Pharmaceutical Industry</a></li>
</div>
<div class="mdl-cell mdl-cell--3-col">
<li class="cat_list_title_color"><a style="color:#135893!important" href="https://www.softwaresuggest.com/project-management-software" target="_self"><b>Project Management & Collaboration</b></a></li>
<li class="cat_list_title_color"><b>Retailing & POS<i class="fa fa-caret-down" aria-hidden="true"></i></b></li>
<li><a class="sub_category" href="https://www.softwaresuggest.com/retail-software" target="_self">Retailing</a></li>
<li><a class="sub_category" href="https://www.softwaresuggest.com/point-of-sale-pos-software" target="_self">Point of Sale</a></li>
<li class="cat_list_title_color"><b>Real Estate & Construction<i class="fa fa-caret-down" aria-hidden="true"></i></b></li>
<li><a class="sub_category" href="https://www.softwaresuggest.com/real-estate-software" target="_self">Real Estate Software</a></li>
<li><a class="sub_category" href="https://www.softwaresuggest.com/construction-management-software" target="_self">Construction Software</a></li>
<li class="cat_list_title_color"><b>System Software<i class="fa fa-caret-down" aria-hidden="true" style="padding-top:3px"></i></b></li>
<li><a class="sub_category" href="https://www.softwaresuggest.com/operating-system" target="_self">Operating System Software</a></li>
<li><a class="sub_category" href="https://www.softwaresuggest.com/firewall-software" target="_self">Firewall Software</a></li>
<li><a class="sub_category" href="https://www.softwaresuggest.com/architecture-software" target="_self">Architecture Software</a></li>
<li><a class="sub_category" href="https://www.softwaresuggest.com/photo-editing-software" target="_self">Photo Editing</a></li>
<li><a class="sub_category" href="https://www.softwaresuggest.com/utility-software" target="_self">Utility Softwares</a></li>
<li class="cat_list_title_color"><a href="https://www.softwaresuggest.com/all-categories" target="_self"><b>All Softwares Categories</b></a></li>
</div>
</div>
</ul>
</li>
<li class="drop drop-service cstyle_same">
<a class="mdl-navigation__link mdl-layout--large-screen-only cat_link">Service Categories <i class="material-icons">keyboard_arrow_down</i></a>
<ul id="service_tab_ul">
<div class="triangle"></div>
<div class="mdl-grid home_drop_tab">
<div class="mdl-cell mdl-cell--12-col service_menu_title_div">
<li class="service_menu_title_li"><a class="service_menu_title" href="https://www.softwaresuggest.com/services" onclick="ga('send','event','N-ServiceHome','RCB-Header','RCB-Header');">Service Hub</a></li>
</div>
<div class="mdl-cell mdl-cell--6-col service_menu_section_box">
<li><a href="https://www.softwaresuggest.com/services/mobile-app-development-companies">Mobile App Development</a></li>
<li><a href="https://www.softwaresuggest.com/services/software-development-companies">Software Development</a></li>
<li><a href="https://www.softwaresuggest.com/services/web-development-companies">Web Development</a></li>
<li><a href="https://www.softwaresuggest.com/services/ecommerce-development-companies">Ecommerce development</a></li>
<li><a href="https://www.softwaresuggest.com/services/digital-marketing-companies">Digital Marketing</a></li>
<li><a href="https://www.softwaresuggest.com/services/seo-companies">SEO Services</a></li>
<li><a href="https://www.softwaresuggest.com/services/web-design-companies">Web Designing(UI/UX)</a></li>
<li><a href="https://www.softwaresuggest.com/services/artificial-intelligence-companies">Artificial Intelligence</a></li>
</div>
<div class="mdl-cell mdl-cell--6-col service_menu_section_box">
<li><a href="https://www.softwaresuggest.com/services/iot-development-companies">IoT Development</a></li>
<li><a href="https://www.softwaresuggest.com/services/testing-service-providers">Testing Services</a></li>
<li><a href="https://www.softwaresuggest.com/services/ar-vr-development-companies">AR & VR Development</a></li>
<li><a href="https://www.softwaresuggest.com/services/blockchain-development-companies">Blockchain Technology</a></li>
<li><a href="https://www.softwaresuggest.com/services/cloud-computing-service-providers">Cloud Computing Services</a></li>
<li><a href="https://www.softwaresuggest.com/services/advertising-agencies">Advertising Services</a></li>
<li><a href="https://www.softwaresuggest.com/services/email-marketing-companies">Email Marketing</a></li>
<li class="cat_list_title_color"><a href="https://www.softwaresuggest.com/services/categories" target="_self"><b>All Service Categories</b></a></li>
</div>
</div>
</ul>
</li>
<nav class="mdl-navigation mdl-layout--large-screen-only">
<form action='https://www.softwaresuggest.com/search/index' method='get'>
<div class="search-container">
<div class="search-box">
<input type="text" id="search" name="query" value="" placeholder="Search software or requirement..." class="search-input cat_srh_cwidth cat-search-input" />
<button class="material-icons search-icon cat-search-btn" id="csearchbtn" type="submit" disabled>search</button>
<span class="search_loader_homepage"></span>
<input type="hidden" name="" id="mdl_hiddensearch" value="">
</div>
</div>
</form>
<a class="mdl-navigation__link button btn btn-reqcall cat-req-btn" data-sid="" data-cat-id="" onclick="ga('send','event','N-RequestACallback','RCB-Header','RCB-Header')"> <button class="mdl-button mdl-js-button head_top_btn">Request A Call Back</button></a>
</nav>

</div>
</header>
<main>

<link rel="stylesheet" href="https://www.softwaresuggest.com/assets2/css/styles.css?v=0.03">

<script type="text/javascript"> ga('send','event','Error','PageNotFound404','szukaj.wp.pl');</script>
<style>
.col-md-3 .error_ul_li ul li {
    font-family: 'Open Sans',sans-serif !important;
    text-decoration: none !important;
	list-style-type: disc !important;
    padding: 3px !important;
}
</style>

<script type='text/javascript' src='https://www.googletagservices.com/tag/js/gpt.js' async></script>
<script>
  var googletag = googletag || {};
  googletag.cmd = googletag.cmd || [];
</script>
<script>
  googletag.cmd.push(function() {
    googletag.defineSlot('/58135396/VisitWebsiteBanner', [768, 1024], 'div-gpt-ad-1479188657254-0').addService(googletag.pubads());
    googletag.pubads().enableSingleRequest();
    googletag.enableServices();
  });
</script>

<section class="mdl-grid mdl-layout__content error_404_page_wrapper">
<div class="mdl-cell mdl-cell--7-col mdl-cell--12-col-phone mdl-cell--12-col-tablet">
<div class="error_page_image">
<img src="https://d1myhw8pp24x4f.cloudfront.net/404-error-page-240x200.jpg">
</div>
</div>
<div class="mdl-cell mdl-cell--5-col mdl-cell--12-col-phone mdl-cell--12-col-tablet">
<a href="https://www.softwaresuggest.com"><div class="error_page_back">PLEASE TAKE ME TO THE HOMEPAGE</div></a>
</div>
<div class="mdl-grid mdl-layout__content">
<div class="mdl-cell mdl-cell--12-col">
<div class="error_page_title_12">
<p>Top Categories</p>
</div>
</div>
<div class="mdl-cell mdl-cell--3-col mdl-cell--4-col-tablet mdl-cell--12-col-phone error_ul_li">
<ul>
<a href="https://www.softwaresuggest.com/accounting-software"><li class="error_li">Accounting Software</li></a>
<a href="https://www.softwaresuggest.com/personal-finance-software"><li>Personal Finance</li></a>
<a href="https://www.softwaresuggest.com/online-accounting-software"><li>Online Accounting </li></a>
<a href="https://www.softwaresuggest.com/financial-management-software"><li>Finance Management</li></a>
<a href="https://www.softwaresuggest.com/fixed-asset-accounting-software"><li>Fixed Asset Accounting</li></a>
<a href="https://www.softwaresuggest.com/billing-invoicing-software"><li> Billing & Invoicing </li></a>
<a href="https://www.softwaresuggest.com/lab-management-software"><li> Lab Management </li></a>
<a href="https://www.softwaresuggest.com/patient-management-software"><li> Patient Management </li></a>
<a href="https://www.softwaresuggest.com/hms-hotel-management-software"><li> Hotel Management </li></a>
<a href="https://www.softwaresuggest.com/restaurant-bar-software"><li> Restaurant & Bar </li></a>
<a href="https://www.softwaresuggest.com/architecture-software"><li> Architecture Software </li></a>
</ul>
</div>
<div class="mdl-cell mdl-cell--3-col mdl-cell--4-col-tablet mdl-cell--12-col-phone error_ul_li">
<ul>
<a href="https://www.softwaresuggest.com/photo-editing-software"><li> Photo Editing Software </li></a>
<a href="https://www.softwaresuggest.com/crm-software"><li>CRM</li></a>
<a href="https://www.softwaresuggest.com/lead-management-system"><li>Lead Management</li></a>
<a href="https://www.softwaresuggest.com/order-management-software"><li>Order Management</li></a>
<a href="https://www.softwaresuggest.com/sfa-sales-force-automation-software"><li>SFA</li></a>
<a href="https://www.softwaresuggest.com/mr-reporting-software"><li>MR Reporting </li></a>
<a href="https://www.softwaresuggest.com/reservation-booking-system"><li>Reservation & Booking</li></a>
<a href="https://www.softwaresuggest.com/spa-salon-software"><li>Spa and Salon</li></a>
<a href="https://www.softwaresuggest.com/property-management-software"><li>Property Management </li></a>
<a href="https://www.softwaresuggest.com/medical-store-software"><li>Medical Store </li></a>
<a href="https://www.softwaresuggest.com/utility-software"><li> Utility Software </li></a>
</ul>
</div>
<div class="mdl-cell mdl-cell--3-col mdl-cell--4-col-tablet mdl-cell--12-col-phone error_ul_li">
<ul>
<a href="https://www.softwaresuggest.com/school-management-software"><li>School Management</li></a>
<a href="https://www.softwaresuggest.com/colleges-universities-software"><li>Colleges & Universities</li></a>
<a href="https://www.softwaresuggest.com/campus-management-software"><li>Campus Management</li></a>
<a href="https://www.softwaresuggest.com/hr-software"><li>HR Software</li></a>
<a href="https://www.softwaresuggest.com/payroll-software"><li>Payroll Software</li></a>
<a href="https://www.softwaresuggest.com/payroll-outsourcing-software"><li>Payroll Outsourcing </li></a>
<a href="https://www.softwaresuggest.com/mr-reporting-software"><li>MR Reporting</li></a>
<a href="https://www.softwaresuggest.com/pharmaceutical-industry-software"><li>Pharmaceutical Industry</li></a>
<a href="https://www.softwaresuggest.com/retail-software"><li>Retailing</li></a>
<a href="https://www.softwaresuggest.com/point-of-sale-pos-software"><li>Point of Sale </li></a>
<a href="https://www.softwaresuggest.com/photo-editing-software"><li> Photo Editing Software </li></a>
</ul>
</div>
<div class="mdl-cell mdl-cell--3-col mdl-cell--4-col-tablet mdl-cell--12-col-phone error_ul_li">
<ul>
<a href="https://www.softwaresuggest.com/applicant-tracking-system"><li>Applicant Tracking System</li></a>
<a href="https://www.softwaresuggest.com/recruiting-software"><li>Recruiting Software</li></a>
<a href="https://www.softwaresuggest.com/online-assessment-software"><li>Online Assessment</li></a>
<a href="https://www.softwaresuggest.com/performance-management-system"><li>Performance Management</li></a>
<a href="https://www.softwaresuggest.com/emr-clinic-management-software"><li>EMR & Clinic Management</li></a>
<a href="https://www.softwaresuggest.com/hospital-management-software"><li>Hospital Management </li></a>
<a href="https://www.softwaresuggest.com/real-estate-software"><li>Real Estate Software</li></a>
<a href="https://www.softwaresuggest.com/construction-management-software"><li>Construction Software</li></a>
<a href="https://www.softwaresuggest.com/operating-system-software"><li>Operating System Software</li></a>
<a href="https://www.softwaresuggest.com/firewall-software"><li>Firewall Software</li></a>
</ul>
</div>
</div>
<div class="mdl-cell mdl-cell--12-col mdl-cell--hide-phone">
<div class="error_page_banner">
<div id='div-gpt-ad-1427785542966-0'>
<script>
                    googletag.cmd.push(function() { googletag.display('div-gpt-ad-1479188657254-0'); });
                    </script>
</div>
</div>
</div>
</section>
</main>
<script type="text/javascript">
    var baseUrl = 'https://www.softwaresuggest.com';
    var price_est_baseUrl = 'https://www.softwaresuggest.com';
    var siteregion = 'india';
    var cont_id = 'site';
    var act_id = 'error';
</script>
<style type="text/css">
/*new footer css*/
  .footer_new_ss{background:#295892;color:#fff}.footer_heading_ss_n{width:100%;padding:0;position:relative;font-size:18px;margin-bottom:10px;font-weight:500;line-height:1.4;color:#fff}.new_footer_ss_ul{margin:0;padding:0;list-style:none}.new_footer_ss_ul li{margin:0;padding:2px 0!important;list-style:none}.new_footer_ss_ul li a{color:#fff;font-weight:400}.footer_highlight_style{background:#ed8900;padding:3px 7px;font-size:13px;font-weight:500!important;border-radius:3px}.footer_add_new{font-size:14px;display:block;margin-bottom:10px;font-style:normal;line-height:1.9}.footer_p_fl{display:flex;color:#fff;margin-top:9px}.icon_pad_righ_f{padding-right:5px;font-size:20px}.underline_footer_titl{border-bottom:1px solid #fff;padding-bottom:3px}.pad_righ_social{padding-right:10px}.inli_footer_new{display:inline-block;margin-right:10px;margin-top:0}.social_img_footer{margin-right:10px;width:24px;height:24px;border:2px solid #fff;border-radius:50%}.ss_footer_social_ico_new a{display:inline-block}.flag_img_footer{margin-right:10px;width:28px;height:20px;border-radius:3px;border:2px solid #fff}.con_foot_affi,.con_foot_new{width:140px;text-align:center;float:left}.cop_margr{margin-left:2px;margin-top:10px}.marg_0_cou{margin-top:0;margin-bottom:0}.con_foot_affi{margin-top:5px}.flo_li_foot{float:left;width:100%}.cen_res_footer_new .mdl-cell{padding:0 25px}.country_flag_footer a{display:inline-block}.country_flag_footer p{margin-bottom:2px}.flag_img_footer.us_flag{background-position: -6px -28.5px;}.flag_img_footer.gcc_flag{background-position: -6px -6px;}.flag_img_footer.india_flag{background-position: -37px -6px}.flag_img_footer.uk_flag{background-position: -3px 19px}.social_img_footer.facebook_footer{background-position: -99px -6px;}.social_img_footer.twitter_footer{background-position: -34px -54px}.social_img_footer.instagram_footer{background-position: -71px -7px;}.social_img_footer.youtube_footer{background-position: -61px 50px;}.social_img_footer.linkedin_footer{background-position: -7px 50px;}@media only screen and (max-width:500px){.cen_res_footer_new{text-align:center}.cen_res_footer_new p{text-align:center}.footer_cen_btn{display:flex;justify-content:center}}@media only screen and (max-width:768px){.cen_res_footer_new{text-align:center}.footer_cen_btn{display:flex;justify-content:center}}@media (min-width:1281px){.mdl-layout__content{padding:10px 70px 20px}}
/*end new footer css*/
.flag_img_footer, .social_img_footer {
    background-image: url("https://www.softwaresuggest.com/assets2/img/footer_all_icon.png?v=0.01");
}
.flag_img_footer {
    background-size: 119px;
}
.social_img_footer {
    background-size: 125px;
}
.cen_res_footer_new_inner{
  padding: unset !important;
  width: unset !important;
  text-align: left !important;
  padding-left: 5px !important;
  padding-right: 5px !important;
}
.social_img_footer{
  margin-right: 0px !important;
}
.flag_img_footer{
  margin-right: 5px !important;
}
.footer_cen_btn{
  justify-content: unset !important;
  word-break: break-all;
}
.social_img_footer{
  margin-right: 10px !important;
}
@media (min-width: 320px) and (max-width: 480px) {
  .footer_add_new{
    width: 132px;
  }
  .with_us_txt{
    display: none;
}
.cen_res_footer_new{
  text-align: unset;
}
.cen_res_footer_new p , .cop_margr{
  text-align: unset !important;
}
.cen_res_footer_new .mdl-cell{
  padding: unset;
}
.social_img_footer{
  margin-right: unset !important;
}
}
</style>
<footer class="footer_new_ss">
<div class="mdl-grid mdl-layout__content cen_res_footer_new">
<div class="mdl-cell mdl-cell--3-col mdl-cell--2-col-phone mdl-cell--4-col-tablet">
<h5 class="footer_heading_ss_n"><span class="underline_footer_titl">For Vendors:</span></h5>
<ul class="new_footer_ss_ul">
<li><a target="_blank" href="https://www.softwaresuggest.com/vendors">Register Your Software</a></li>
<li><a target="_blank" href="https://www.softwaresuggest.com/price-estimator" class="footer_highlight_style">Price Estimator </a></li>
<li><a rel="nofollow" target="_blank" href="https://www.softwaresuggest.com/vendorsportal/index.php?r=site/login" class="footer_highlight_style">Vendors Portal </a></li>
<li><a rel="nofollow" target="_blank" href="https://www.softwaresuggest.com/write-review">Write Review</a></li>

<li><a target="_blank" href="https://www.softwaresuggest.com/award">Award</a></li>

</ul>
</div>
<div class="mdl-cell mdl-cell--3-col mdl-cell--2-col-phone mdl-cell--4-col-tablet">
<h5 class="footer_heading_ss_n"><span class="underline_footer_titl">For Buyers:</span></h5>
<ul class="new_footer_ss_ul">
<li><a rel="nofollow" target="_blank" href="https://www.softwaresuggest.com/all-categories">All Categories</a></li>
<li><a target="_blank" href="https://www.softwaresuggest.com/success-stories">Success Stories</a></li>
<li><a target="_blank" href="https://www.softwaresuggest.com/reports">Reports</a></li>
<li><a target="_blank" href="https://www.softwaresuggest.com/blog/">Blog</a></li>
<li><a target="_blank" href="https://www.softwaresuggest.com/blog/ebooks/">Free Ebooks</a></li>
<li><a rel="nofollow" target="_blank" href="https://www.softwaresuggest.com/contribution">Contribution</a></li>
<li><a rel="nofollow" target="_blank" href="https://www.softwaresuggest.com/mediacoverage">Media Coverage </a></li>
<li class="footer_cen_btn">
<a rel="nofollow" target="_blank" href="https://www.softwaresuggest.com/consultants">Consultant Program</a>
</li>

</ul>
</div>
<div class="mdl-cell mdl-cell--3-col mdl-cell--2-col-phone mdl-cell--4-col-tablet">
<h5 class="footer_heading_ss_n"><span class="underline_footer_titl">About Company:</span></h5>
<ul class="new_footer_ss_ul">
<li><a target="_blank" href="https://www.softwaresuggest.com/about">About Us</a></li>
<li><a target="_blank" href="https://www.softwaresuggest.com/tos">Terms of Use</a></li>
<li><a target="_blank" href="https://www.softwaresuggest.com/privacy">Privacy Policy</a></li>
<li><a rel="nofollow" target="_blank" href="https://appitsimple.com/current-opening">Careers <span class="footer_highlight_style"> We are hiring</span></a></li>
<li class="country_flag_footer">
<p class="marg_0_cou">Select your country:</p>
<a href="https://www.softwaresuggest.com">
<div class="flag_img_footer india_flag"></div>
</a>
<a href="https://www.softwaresuggest.com/us/" target="_blank">
<div class="flag_img_footer us_flag"></div>
</a>
<a href="https://www.softwaresuggest.com/gcc/" target="_blank">
<div class="flag_img_footer gcc_flag"></div>
</a>
<a href="https://www.softwaresuggest.co.uk" target="_blank">
<div class="flag_img_footer uk_flag"></div>
</a>
</li>
</ul>
</div>
<div class="mdl-cell mdl-cell--3-col mdl-cell--2-col-phone mdl-cell--4-col-tablet">
<h5 class="footer_heading_ss_n"><span class="underline_footer_titl">Get In Touch <span class="with_us_txt">With Us</span>:</span></h5>
<address class="footer_add_new">
<strong>AppItsimple Infotek Pvt. Ltd.</strong>

</address>
<div class="ss_footer_social_ico_new">
<a href="https://www.facebook.com/SoftwareSuggest" target="_blank">
<div class="social_img_footer facebook_footer"></div>
</a>
<a href="https://www.twitter.com/SoftwareSuggest" target="_blank">
<div class="social_img_footer twitter_footer"></div>
</a>
<a href="https://www.instagram.com/softwaresuggest_ss/" target="_blank">
<div class="social_img_footer instagram_footer"></div>
</a>
<a href="https://www.youtube.com/user/SoftwareSuggest/videos" target="_blank">
<div class="social_img_footer youtube_footer"></div>
</a>
<a href="https://www.linkedin.com/company/softwaresuggest" target="_blank">
<div class="social_img_footer linkedin_footer"></div>
</a>
</div>
<a class="footer_p_fl footer_cen_btn" href="mailto:team@softwaresuggest.com"><i class="material-icons icon_pad_righ_f">email</i> team@softwaresuggest.com</a>
<p class="cop_margr">&copy; 2014 - 2020 SoftwareSuggest &reg;</p>
</div>
</div>
</footer>
<div id="sa_vf"></div>
<a href="#" class="scrollup" style="display:none">Scroll</a>
<script type="text/javascript">
  var mobile_app_page_accordian_source = '';
</script>
<script type="text/javascript">
	var is_service_profile = '';
	var is_software_profile = '';
	var is_mobileapp_profile = '';
</script>
<style type="text/css">
    .modal-footer.callback_footer {
        padding-bottom: 0px;
    }
    #req_callback .terms_check_div{
        padding-top: 0 !important;
        padding-bottom: 0;
        text-align: center;
    }
    #req_callback .terms_div_req{
        margin: 0 auto;
    }
    #req_callback .tos_span_form{
        font-size: 9px;
    }
    #req_callback .iti {
        width: 100%;
    }
    @media only screen and (min-width: 768px) {
        #req_callback .terms_check_div{
            padding: 0 !important;
        }
    }
</style>
<div id="req_callback" class="">
<div class="modal fade in mobile_modal c_width_850px">
<div class="modal-dialog">
 <div class="modal-content">
<div style="display:block" id="modal-content-form">
<div class="modal-header home_modal_header">
<button type="button" class="close" data-dismiss="modal">
<i class="fa fa-times" aria-hidden="true"></i><span class="sr-only">Close</span>
</button>
<div class="mdl-grid nopad padding_top_bot_0">
<div class="mdl-cell mdl-cell--12-col req-header" style="position:relative;">
<h4>Need Help Selecting The Right Software?</h4>
</div>
</div>
</div>
<div class="modal-body nopad">
<div class="mdl-grid ">
<div class="" id="req_callback_success" style="max-height: auto!important;display:none; height:auto !important;">
<div class="mdl-dialog__content">
<h6 class="thankyou_message">
Thank you for the enquiry.Our software experts will contact you in next 1 hour.
</h6>
</div>
</div>
<div class="mdl-grid popup_main_div padding_top_bot_0" id="req_callback_form">
<div class="mdl-cell mdl-cell--12-col nomargin mdl-cell--hide-phone">
<div class="mgetquote_bodytitle">Discover Top Business Software & Service Partners
</div>
</div>
<div class="mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet mdl-cell--6-col-desktop mdl-cell--hide-phone nomargin req-back-sidebar">
<div class="mdl-cell mdl-cell--12-col display-flex">
<div class="mdl-cell mdl-cell--6-col mdl-cell--12-col-phone mdl-cell--12-col-tablet">
<div class="text-centered">
<div class="req_call_img1 free_con_feature_img">
</div>
</div>
<div>
<h3 class="free_con_4grid_text">Get Expert Assistance</h3>
</div>
</div>
<div class="mdl-cell mdl-cell--6-col mdl-cell--12-col-phone mdl-cell--12-col-tablet">
<div class="text-centered">
<div class="req_call_img2 free_con_feature_img">
</div>
</div>
<div>
<h3 class="free_con_4grid_text">Save Time and Money</h3>
</div>
</div>
</div>
<div class="mdl-cell mdl-cell--12-col display-flex">
<div class="mdl-cell mdl-cell--6-col mdl-cell--12-col-phone mdl-cell--12-col-tablet">
<div class="text-centered">
<div class="req_call_img3 free_con_feature_img">
</div>
</div>
<div>
<h3 class="free_con_4grid_text">Avoid Mistakes</h3>
 </div>
</div>
<div class="mdl-cell mdl-cell--6-col mdl-cell--12-col-phone mdl-cell--12-col-tablet">
<div class="text-centered">
<div class="req_call_img4 free_con_feature_img">
</div>
</div>
<div>
<h3 class="free_con_4grid_text">Get Wide Option</h3>
</div>
</div>
</div>
</div>
<div class="mdl-cell mdl-cell--4-col-tablet mdl-cell--6-col nomargin req_mobile_width">
<fieldset id="rcfirst" class="cfieldset">
<form id="req_callback_f1" name="req_callback_f1" method="post">
<input type="hidden" id="req_countrycode" name="req_countrycode" />
<input type="hidden" id="formname" name="formname" value="firstform" />
<input type="hidden" id="req_category" name="FreeConsultation[categories]" value="" />
<input type="hidden" id="req_soft_id" name="FreeConsultation[soft_id]" value="" />
<input type="hidden" class="is_mobile_no_valid" name="ssleadpost[is_mobile_no_valid]">
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label popup_input_div">
<input class="mdl-textfield__input" id="FreeConsultation_lastname" pattern="^[a-zA-Z0-9].*" type="text" value="" name="FreeConsultation[lastname]" required="1">
<label class="mdl-textfield__label" for="FreeConsultation_lastname" style="color:rgba(0,0,0,0.7) !important;font-size: 14px;top: 0;">Name *</label>
</div>
<div style="" class="error_message_name free-consult-error" style="display: none;"></div>
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label popup_input_div">
<input class="mdl-textfield__input" id="FreeConsultation_email" type="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,6}$" value="" name="FreeConsultation[email]" required="1">
<label class="mdl-textfield__label " for="FreeConsultation_email" style="color:rgba(0,0,0,0.7) !important;font-size: 14px;top: 0;">Business Email *</label>
</div>
<div style="" class="error_message_email free-consult-error" style="display: none;"></div>
<input class="mdl-textfield__input" id="countrycode_req23" type="hidden" value="" name="countrycode">
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label popup_input_div" style="font-size: 14px;">
<input class="mdl-textfield__input ssintlTelInput" style="padding-left: 84px;" id="FreeConsultation_phone" type="tel" value="" onkeypress="return event.charCode >= 48 && event.charCode <= 57" pattern="^[0-9].*" name="FreeConsultation[phone]" required="1" maxlength="12">
<label class="mdl-textfield__label" for="FreeConsultation_phone" style="color:rgba(0,0,0,0.7) !important; top:0;font-size: 14px;">Phone Number *</label>
 <span id="cat_home_request_popup"></span>
</div>
<div style="" class="error_message_phone free-consult-error" style="display: none;"></div>
<div class="mdl-dialog__actions mdl-dialog__actions--full-width" style="vertical-align:middle;display: inline-block;width:100%;text-align:center;">
<input type="submit" class="mdl-button mdl-js-button mdl-button--raised mdl-button--colored" style="height: 0%;text-align: center;" name="next" value="Submit" id="rfnext_btn">
</div>
</form>
</fieldset>
<fieldset id="rcsecond" class="cfieldset" style="display: none;">
<form id="req_callback_f2" name="req_callback_f2" method="post">
<input type="hidden" id="formname" value="secondform" name="formname" />
<input type="hidden" id="FreeConsultation_clid2" name="FreeConsultation[clid]" />
<div style="" class="error_message_organization free-consult-error" style="display: none;"></div>
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label popup_input_div">
<input class="mdl-textfield__input" id="FreeConsultation_company" pattern="^[a-zA-Z0-9].*" type="text" value="" name="FreeConsultation[company]" required="1">
<label class="mdl-textfield__label" for="txtname" style="color:rgba(0,0,0,0.7) !important;top:0;">Company Name *</label>
</div>
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label popup_input_div">
<select class="mdl-textfield__input" style="font-size: 14px !important;" id="FreeConsultation_industry" name="FreeConsultation[industry]" required="1">
<option value="">-- Select Industry --</option>
<option value="Accounting / CPA">Accounting / CPA</option>
<option value="Advertising">Advertising</option>
<option value="Agriculture">Agriculture</option>
<option value="Architecture">Architecture</option>
<option value="Auto Dealership">Auto Dealership</option>
<option value="Banking">Banking</option>
<option value="Banking & Mortgage">Banking & Mortgage</option>
<option value="Construction / Contracting">Construction / Contracting</option>
<option value="Consulting">Consulting</option>
<option value="Distribution">Distribution</option>
<option value="Education">Education</option>
<option value="Engineering">Engineering</option>
<option value="Food / Beverage">Food / Beverage</option>
<option value="Government Agencies">Government Agencies</option>
<option value="Government Contractors">Government Contractors</option>
<option value="Healthcare / Social Services">Healthcare / Social Services</option>
<option value="Hospitality / Travel">Hospitality / Travel</option>
<option value="Insurance">Insurance</option>
<option value="Legal / Law Firm">Legal / Law Firm</option>
<option value="Marketing Services">Marketing Services</option>
<option value="Maintenance / Field Service">Maintenance / Field Service</option>
<option value="Manufacturing">Manufacturing</option>
<option value="Media & Newspaper">Media & Newspaper</option>
<option value="Nonprofit">Nonprofit</option>
<option value="Oil & Gas">Oil & Gas</option>
<option value="Pharmaceuticals">Pharmaceuticals</option>
<option value="Property Management">Property Management</option>
<option value="Real Estate">Real Estate</option>
<option value="Retail">Retail</option>
<option value="Software / Technology">Software / Technology</option>
<option value="Transportation">Transportation</option>
<option value="Telecommunications">Telecommunications</option>
<option value="Utilities">Utilities</option>
<option value="Other">Other</option>
</select>
 <label class="mdl-textfield__label" for="FreeConsultation_industry" style="color:rgba(0,0,0,0.7) !important;font-size: 14px;top: 0;">Industry *</label>
</div>
<div style="" class="error_message_industry free-consult-error" style="display: none;"></div>
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label popup_input_div" style="font-size: 14px;">
<input class="mdl-textfield__input" id="FreeConsultation_city" pattern="^[a-zA-Z].*" type="text" value="" name="FreeConsultation[city]" required="1">
<label class="mdl-textfield__label" for="FreeConsultation_city" style="color:rgba(0,0,0,0.7) !important;">City *</label>
</div>
<div style="" class="error_message_city free-consult-error" style="display: none;"></div>
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label popup_input_div">
<textarea class="mdl-textfield__input" required="1" id="FreeConsultation_req" name="FreeConsultation[requirement]" value=""></textarea>
<label class="mdl-textfield__label" for="FreeConsultation_req" style="color:rgba(0,0,0,0.7) !important;font-size: 14px;">Requirements*</label>
</div>
<div style="" class="error_message_requirement free-consult-error" style="display: none;"></div>
<div class="mdl-dialog__actions mdl-dialog__actions--full-width" style="vertical-align:middle;display: inline-block;width:100%;text-align:center;">
<input type="submit" class="mdl-button mdl-js-button mdl-button--raised mdl-button--colored " style="height: 0%;text-align: center;" name="next" value="Submit" id="rsnext_btn">
</div>
</form>
</fieldset>
<fieldset id="rcthird" class="cfieldset" style="display: none;">
<form id="req_callback_f3" name="req_callback_f3" method="post">
<p class="h2_p" style="color:red; display: none;" id="msg2"></p>
<input type="hidden" id="formname" value="thirdform" name="formname" />
<input type="hidden" id="FreeConsultation_clid3" name="FreeConsultation[clid]" />
<div style="" class="error_message_designation free-consult-error" style="display: none;"></div>
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label popup_input_div" style="font-size: 14px;">
<select class="mdl-textfield__input" style="font-size: 14px !important;" id="FreeConsultation_designation" name="FreeConsultation[designation]" required="1">
<option value="">-- Select Designation --</option>
<option value="Accountant">Accountant</option>
<option value="President">President</option>
<option value="Chairman">Chairman</option>
 <option value="Consultant">Consultant</option>
<option value="CEO">CEO</option>
<option value="CXO">CXO</option>
<option value="Designer">Designer</option>
<option value="Developer">Developer</option>
<option value="Assistant Manager">Assistant Manager</option>
<option value="Doctor">Doctor</option>
<option value="Director">Director</option>
<option value="Engineer">Engineer</option>
<option value="Executive">Executive</option>
<option value="Freelancer">Freelancer</option>
<option value="General Manager">General Manager</option>
<option value="Clerk">Clerk</option>
<option value="Managing Director">Managing Director</option>
<option value="Chief Financial officer">Chief Financial officer</option>
<option value="IT Manager">IT Manager</option>
<option value="Manager">Manager</option>
<option value="Owner/Proprietor">Owner/Proprietor</option>
<option value="Supervisor">Supervisor</option>
<option value="Vice President">Vice President</option>
<option value="Committee Member">Committee Member</option>
<option value="Society Member">Society Member</option>
<option value="Trustee">Trustee</option>
<option value="Secretary">Secretary</option>
<option value="Partner">Partner</option>
<option value="HR Manager">HR Manager</option>
<option value="HR Executive">HR Executive</option>
<option value="Admin">Admin</option>
<option value="Principal">Principal</option>
<option value="Regional Director">Regional Director</option>
<option value="Regional Manager">Regional Manager</option>
</select>
<label class="mdl-textfield__label" for="FreeConsultation_designation" style="color:rgba(0,0,0,0.7) !important; top: 0;">Designation *</label>
</div>
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label popup_input_div">
<select class="mdl-textfield__input" style="font-size: 14px !important;" id="FreeConsultation_empno" name="FreeConsultation[empno]" required="1">
<option value="">-- Select No. of Employees --</option>
<option value="Less than 50
                                                        ">Less than 50</option>
<option value="50-100">50-100</option>
<option value="100-500">100-500</option>
<option value="500-1000">500-1000</option>
<option value="More than 1000">More than 1000</option>
</select>
<label class="mdl-textfield__label" for="txtprefer_time_to_call" style="color:rgba(0,0,0,0.7) !important;top: 0;">Number of Employees in company *</label>
</div>
<div style="" class="error_message_empno free-consult-error" style="display: none;"></div>
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label popup_input_div">
<select class="mdl-textfield__input" style="font-size: 14px !important;" id="FreeConsultation_users" name="FreeConsultation[software_users]" required="1">
<option value="">-- Select No. of Software Users --</option>
<option value="Less than 5">Less than 5</option>
<option value="5 to 10">5 to 10</option>
<option value="10 to 30">10 to 30</option>
<option value="30 to 50">30 to 50</option>
<option value="More than 50">More than 50</option>
 </select>
<label class="mdl-textfield__label" for="txtprefer_time_to_call" style="color:rgba(0,0,0,0.7) !important;top: 0;">Number of Software Users *</label>
</div>
<div style="" class="error_message_softuno free-consult-error" style="display: none;"></div>
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label popup_input_div">
<select class="mdl-textfield__input" style="font-size: 14px !important;" id="FreeConsultation_time_to_call" name="FreeConsultation[time_to_call]" required="1">
<option value="">-- Select Preferred Time To Call --</option>
<option value="All Day">All Day</option>
<option value="Morning">Morning</option>
<option value="Noon">Noon</option>
<option value="Evening">Evening</option>
</select>
<label class="mdl-textfield__label preferredLabel" for="FreeConsultation_time_to_call" style="color:rgba(0,0,0,0.7) !important;top: 0;">Preferred time for us to call*</label>
</div>
<div style="" class="error_message_prefertime free-consult-error" style="display: none;"></div>
<div class="mdl-dialog__actions mdl-dialog__actions--full-width middle-inline">
<input class="mdl-button mdl-js-button mdl-button--raised mdl-button--colored " style="text-align: center;height: 0%" type="submit" value="Submit" id="rtnext_btn">
</div>
</form>
</fieldset>
<fieldset class="cfieldset" id="rcfourth">
<form id="req_callback_f4" name="req_callback_f4" method="post">
<input type="hidden" id="formname" value="fourthform" name="formname" />
<input type="hidden" id="FreeConsultation_clid4" name="FreeConsultation[clid]" />
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label popup_input_div">
<select class="mdl-textfield__input" style="font-size: 14px !important;" id="FreeConsultation_deployment" name="FreeConsultation[deployment]" required="1">
<option value="">-- Select Deployment --</option>
<option value="Cloud Based">Cloud Based</option>
<option value="On Premises">On Premises</option>
<option value="Hybrid">Hybrid</option>
 <option value="Any">Any</option>
</select>
<label class="mdl-textfield__label" for="FreeConsultation_deployment" style="color:rgba(0,0,0,0.7) !important;font-size: 14px;top: 0;">Deployment*</label>
</div>
<div style="" class="error_message_deployment free-consult-error" style="display: none;"></div>
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label popup_input_div">
<input class="mdl-textfield__input" id="FreeConsultation_budget" type="text" pattern="^[a-zA-Z0-9].*" value="" name="FreeConsultation[budget]" required="1">
<label class="mdl-textfield__label" for="FreeConsultation_budget" style="color:rgba(0,0,0,0.7) !important;font-size: 14px;">Budget *</label>
</div>
<div style="" class="error_message_budget free-consult-error" style="display: none;"></div>
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label popup_input_div">
<input class="mdl-textfield__input" id="FreeConsultation_current_soft" pattern="^[a-zA-Z0-9].*" type="text" value="" name="FreeConsultation[current_soft]" required="1">
<label class="mdl-textfield__label" for="FreeConsultation_current_soft" style="color:rgba(0,0,0,0.7) !important;font-size: 14px;"> Current software*</label>
</div>
<div style="" class="error_message_currentsoft free-consult-error" style="display: none;"></div>
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label popup_input_div">
<input type="text" class="mdl-textfield__input" required="1" id="FreeConsultation_reason" pattern="^[a-zA-Z0-9].*" name="FreeConsultation[reason_to_change]" value="" required="1">
<label class="mdl-textfield__label" for="FreeConsultation_reason" style="color:rgba(0,0,0,0.7) !important;font-size: 14px;">Reason to Changes*</label>
</div>
<div style="" class="error_message_reason free-consult-error" style="display: none;"></div>
<div class="mdl-dialog__actions mdl-dialog__actions--full-width middle-inline">
<input class="mdl-button mdl-js-button mdl-button--raised mdl-button--colored " style="text-align: center;height: 0%" type="submit" value="submit" id="r4next_btn">
</div>
</form>
</fieldset>
</div>
</div>
</div>
</div>
</div>
<div class="modal-footer callback_footer home_getpopup_dis_block">
<div class="mdl-grid">
<div class="mdl-cell mdl-cell--12-col mdl-cell--hide-phone margin0">
<img src="https://www.softwaresuggest.com/assets2/img/happycustomer/popup_stripe.png?v=0.01" class="img_sati_part">
</div>
<div class="mdl-cell mdl-cell--12-col terms_div_req">
<div class="mdl-textfield mdl-js-textfield terms_check_div">
<span class="tos_span_form">By submitting, you agree to our <a href="https://www.softwaresuggest.com/tos" target="_blank">Terms of Use</a> and <a href="https://www.softwaresuggest.com/privacy" target="_blank">Privacy Policy</a>.</span>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<style type="text/css">

.intl-tel-input .country-name
{
  margin-right: 6px;
  margin-left: 11px;
}

.input_us_style{
   width: 100% !important;
   border-radius: 3px !important;
   border: 1px solid #bdbdbd !important;
   height: 40px !important;
   padding: 5px 12px;
}
.req_us_lineh{
    line-height: 2;
}
.select2-container--default .select2-selection--single .select2-selection__arrow{
    top: 7px;
}
.input_btm_line.is-invalid .mdl-textfield__label:after{
    background-color: unset !important;
}
.input_btm_line:after{
        background-color: unset !important;
}
.us_modal_style{
   max-width: 100% ;
   height: 100% ;
   margin: 0px ;
   width: 100% ;
   border: 0px;
   border-radius: 0px !important;
}
.us_pad_bot0{
    padding-bottom: 0;
}
.us_marg_bot{
    margin-bottom: 10px;
}
.us_submit_bot{
    padding-bottom: 15px;
}
.mdl-textfield.is-invalid .mdl-textfield__input{
    border-color: #bdbdbd !important
}
 .input_us_style .intl-tel-input .selected-flag .iti-flag{
    left: 8px !important;
}
.us_secure_msg{
    display: flex;
    align-items: center;
    justify-content: center;    
}
.us_secure_img{
    width: 25px;
    margin-right: 8px;
}
.pop_center_new{
    display: flex;
    align-items: center;
}
.us_logo_img{
    text-align: center;
}
.modal .us_touch_shortly{
    margin-bottom: 0px;
    color: black;
}
#getquote_form1 .us_touch_shortly{
    font-size: 13.7px;
}
.getQuote_modal_title{
    margin: 5px 0 10px 0;
    text-align: center;
    padding: 0 25px;
    font-size: 20px;
    text-transform: capitalize;
}
.getQuote_btn_div{
    width: 100%;
}
.mdl-textfield.mdl-js-textfield.mdl-textfield--floating-label.popup_input_div.is-invalid.is-upgraded, .mdl-textfield.mdl-js-textfield.mdl-textfield--floating-label.popup_input_div{
    width: 100%;
}
.us_ss_styl{
    color: #135893;
   font-weight: 500;

}
.us_subbtn_styl.mdl-button--raised.mdl-button--colored{
    width: 100%;
    height: 50px;
    text-align: center;
    margin-top: 20px;
    font-size: 17px;
    letter-spacing: .05em;
    background-color: #0088f6;
}
.ss_popup_modal_div{
    max-width: 550px;
}
.us_close_btn{
    top: 10px !important;
    right: 23px !important;
}
.secured_p_msg{
    text-align: center;
    font-size: 14.5px;
}
.flag_marg_new .iti-flag{
    margin-left: 10px !important;
}
.new_thks_style{
        height: 380px !important;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 20px;
}
.input_gcc_style .select2-container{
    width: 100%;
   border-radius: 3px !important;
   border: 1px solid #bdbdbd !important;
   height: 40px !important;
   padding: 5px 12px;
  }
  .input_gcc_style .select2-selection{
     border-bottom: 0 !important;
  }
  .pop_title_new_des{
    padding-left: 30px;
  }
#getQuote .iti {
  width: 100%;
}
@media only screen and (max-width: 500px){
    #getQuote .modal {
        top: 40%;
    }
    .us_touch_shortly{
        display: none;
    }
    .us_modal_style{
        height: unset;
        margin-right: auto;
        margin-left: auto;
        margin-top: -175px;
    }
    .popup_mobile_title_div{
        margin-bottom: 15px;
    }
    .us_pad_top0{
        padding-top: 0;
    }
    .mobile_us_none{
        display: none;
    }
    .flag_marg_new .iti-flag{
    margin-left: 0px !important;
    }
    .mdl-textfield.mdl-js-textfield.mdl-textfield--floating-label.popup_input_div.is-invalid.is-upgraded, .mdl-textfield.mdl-js-textfield.mdl-textfield--floating-label.popup_input_div {
    width: 100% !important;
    margin-left: 0px;
    }
    .us_marg_bot{
        margin-bottom: 0 !important;
    }
    .new_thks_style{
        height: 150px !important;
    }
    .popup_mobile_req_demo_p{
    width: 80%;
    margin: 0 auto !important;
    font-weight: 500;
    line-height: 1.5;
    }
    .pop_title_new_des{
    padding-left: 0px;
    width: 100%;
    }
    .secured_p_msg{
        text-align: center;
        font-size: 10px;
    }

    .intl-tel-input .selected-flag .iti-flag{
        left: 10px;
    }
    .getQuote_modal_title {
      font-size: 15px;
      line-height: 25px;
    }
    .us_subbtn_styl.mdl-button--raised.mdl-button--colored {
        font-size: 14px;
    }
}
@media only screen and (min-width: 768px){
    .thank_us_msg{
       background: #d1ebff;
       width: 452px;
       margin: 0 auto;
       padding: 22px 26px !important;
       font-size: 18px !important;
       border: 1px solid #a9c5da;
       height: 8em;
    }
    .thank_msg_center{
        height: 27em;
        display: flex;
        align-items: center;
    }
}
.form_tos_div label {
    display: flex;
    align-items: center;
}
.form_tos_div {
    padding-bottom: 0;
}
.mdl-button.mdl-button--disabled.mdl-button--disabled, .mdl-button[disabled][disabled] {
    color: rgba(0, 0, 0, .26) !important;
    cursor: default !important;
    background-color: rgba(0, 0, 0, .12) !important;
}
</style>
<div id="getQuote">
<div class="modal ss_popup_modal_div">
<div class="modal-dialog">
<div class="modal-content">
<a class="close us_close_btn"><i class="material-icons close_btn_i">close</i></a>
<div class="mdl-grid mdl-grid--no-spacing">
<div class="mdl-cell mdl-cell--12-col mdl-cell--12-col-tablet">
<div class="">
<h5 class="getQuote_modal_title" id="get_quote_title">Get Quote for Aarogya </h5>
</div>
</div>
<hr style="background: #dedede;width: 100%;">
</div>
<div class="content new_thks_style" id="modal-get-quote-content-id" style="max-height: auto!important;display:none;">
<div class="mdl-dialog__content thank_us_msg">
<h6 class="thankyou_message_poup" style="font-size: 17px !important">Thank you for the enquiry. One of our software analysts will contact you in next 1 hour. </h6>
</div>
</div>
<div class="mdl-grid nopadding content_form_home" id="content_form">
<div class="mdl-cell mdl-cell--12-col mdl-cell--12-col-desktop mdl-cell--12-col-tablet">
<div class="mgetquote_bodyform">
<fieldset id="first" class="cfieldset gq_cfieldset">
<form id="getquote_form1" style="text-align: center;">
<input type="hidden" name="sname" id="sname">
<input type="hidden" name="sid" id="sid">
<input type="hidden" name="cid" id="cid">
<input type="hidden" name="type" id="type">
<input type="hidden" name="category" id="category" class="getQuote_home_issue">
<input type="hidden" class="is_mobile_no_valid" name="ssleadpost[is_mobile_no_valid]">
<input type="hidden" name="firstform" id="firstform" value="firstform">
<p class="us_touch_shortly">Just one step away from selecting the right software</p>
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label popup_input_div us_pad_bot0">
<input class="mdl-textfield__input input_us_style" id="txtname1" pattern="^[a-zA-Z0-9].*" type="text" value="" placeholder="Name *" name="txtname" required="1">
<label class="mdl-textfield__label input_btm_line" for="txtname" style="color:rgba(0,0,0,0.7) !important;top:0;"></label>
</div>
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label popup_input_div us_pad_bot0">
<input class="mdl-textfield__input input_us_style" id="txtemail1" type="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,6}$" placeholder="Business Email *" value="" name="txtemail" required="1">
<label class="mdl-textfield__label input_btm_line" for="txtemail" style="color:rgba(0,0,0,0.7) !important;top:0;"></label>
</div>
<input class="mdl-textfield__input" id="countrycode_getquote1" type="hidden" value="" name="countrycode">
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label popup_input_div us_pad_bot0 flag_marg_new">
<input class="mdl-textfield__input input_us_style ssintlTelInput" pattern="^[0-9].*" placeholder="Phone Number *" id="txtphone1" onkeypress="return event.charCode >= 48 && event.charCode <= 57" type="tel" value="" name="txtphone" required="1" maxlength="12">
<label class="mdl-textfield__label input_btm_line" for="txtphone" style="color:rgba(0,0,0,0.7) !important; top:0;"></label>
<span id="mblmsg"></span>
 </div>
<div class="getQuote_btn_div">
<button type="submit" class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-button--colored btn-block us_subbtn_styl" name="next" id="next_btn">Get Pricing</button>
</div>
</form>
</fieldset>
<fieldset class="cfieldset gq_cfieldset">
<form class="regform" id="getquote_form2" style="text-align: center;">
<p class="h2_p" style="color:red; display: none;" id="msg2"></p>
<input type="hidden" name="category" id="category">
<input type="hidden" name="clid" id="clid">
<p class="us_touch_shortly">Help us better understand your business requirements</p>
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label popup_input_div us_pad_bot0 us_pad_top0 has-placeholder is-upgraded is-dirty" data-upgraded=",MaterialTextfield">
<input class="mdl-textfield__input input_us_style" id="free_txtorganization" pattern="^[a-zA-Z0-9].*" type="text" placeholder="Company Name *" value="" name="txtorganization" required="1">
<label class="mdl-textfield__label input_btm_line" for="txtname" style="color:rgba(0,0,0,0.7) !important;top:0;"></label>
</div>
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label popup_input_div us_pad_bot0">

<select class="mdl-textfield__input input_us_style" style="font-size: 14px !important;" id="txtindustry" name="txtindustry" required="1">
<option value="">-- Select Industry --</option>
<option value="Accounting / CPA">Accounting / CPA</option>
<option value="Advertising">Advertising</option>
<option value="Agriculture">Agriculture</option>
<option value="Architecture">Architecture</option>
<option value="Auto Dealership">Auto Dealership</option>
<option value="Banking">Banking</option>
<option value="Banking & Mortgage">Banking & Mortgage</option>
<option value="Construction / Contracting">Construction / Contracting</option>
<option value="Consulting">Consulting</option>
<option value="Distribution">Distribution</option>
<option value="Education">Education</option>
<option value="Engineering">Engineering</option>
 <option value="Food / Beverage">Food / Beverage</option>
<option value="Government Agencies">Government Agencies</option>
<option value="Government Contractors">Government Contractors</option>
<option value="Healthcare / Social Services">Healthcare / Social Services</option>
<option value="Hospitality / Travel">Hospitality / Travel</option>
<option value="Insurance">Insurance</option>
<option value="Legal / Law Firm">Legal / Law Firm</option>
<option value="Marketing Services">Marketing Services</option>
<option value="Maintenance / Field Service">Maintenance / Field Service</option>
<option value="Manufacturing">Manufacturing</option>
<option value="Media & Newspaper">Media & Newspaper</option>
<option value="Nonprofit">Nonprofit</option>
<option value="Oil & Gas">Oil & Gas</option>
<option value="Pharmaceuticals">Pharmaceuticals</option>
<option value="Property Management">Property Management</option>
<option value="Real Estate">Real Estate</option>
<option value="Retail">Retail</option>
<option value="Software / Technology">Software / Technology</option>
<option value="Transportation">Transportation</option>
<option value="Telecommunications">Telecommunications</option>
<option value="Utilities">Utilities</option>
<option value="Other">Other</option>
</select>
<label class="mdl-textfield__label input_btm_line" for="txtindustry" style="color:rgba(0,0,0,0.7) !important; top: 0;"></label>
</div>
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label popup_input_div us_pad_bot0">
<input class="mdl-textfield__input input_us_style" id="txtcity" type="text" pattern="^[a-zA-Z0-9].*" placeholder="City*" value="" name="txtcity" required="1">
<label class="mdl-textfield__label input_btm_line" for="txtcity" style="color:rgba(0,0,0,0.7) !important;"></label>
</div>
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label popup_input_div us_pad_bot0">
<textarea class="mdl-textfield__input input_us_style req_us_lineh" required="1" id="txtdescription" placeholder="Requirements*" pattern="^[a-zA-Z0-9].*" name="txtdescription" value=""></textarea>
<label class="mdl-textfield__label input_btm_line" for="txtdescription" style="color:rgba(0,0,0,0.7) !important;"></label>
</div>
<div class="mdl-dialog__actions mdl-dialog__actions--full-width middle-inline" id="pre_div">
<input class="mdl-button mdl-js-button mdl-button--raised mdl-button--colored btn-block input_us_style" style="height: 0%" type="button" value="Previous" id="pre_btn">
</div>
<div class="getQuote_btn_div">
<button class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-button--colored btn-block us_subbtn_styl" type="submit" id="submit_btn">SUBMIT</button>
</div>
</form>
</fieldset>

<fieldset class="cfieldset gq_cfieldset" id="fieldsetform">
<form class="regform" id="getquote_form3" style="text-align: center;">
<input type="hidden" name="category" id="category">
<input type="hidden" name="clid" id="clid">
<p class="us_touch_shortly">A little more about the business & preferred time of the call</p>
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label popup_input_div us_submit_bot" style="padding-bottom: 0">

<select class="mdl-textfield__input input_us_style" style="font-size: 14px !important;" id="gq_txtdesignation" name="txtdesignation" required="1">
<option value="">-- Select Designation --</option>
<option value="Accountant">Accountant</option>
<option value="President">President</option>
<option value="Chairman">Chairman</option>
<option value="Consultant">Consultant</option>
<option value="CEO">CEO</option>
<option value="CXO">CXO</option>
<option value="Designer">Designer</option>
<option value="Developer">Developer</option>
 <option value="Assistant Manager">Assistant Manager</option>
<option value="Doctor">Doctor</option>
<option value="Director">Director</option>
<option value="Engineer">Engineer</option>
<option value="Executive">Executive</option>
<option value="Freelancer">Freelancer</option>
<option value="General Manager">General Manager</option>
<option value="Clerk">Clerk</option>
<option value="Managing Director">Managing Director</option>
<option value="Chief Financial officer">Chief Financial officer</option>
<option value="IT Manager">IT Manager</option>
<option value="Manager">Manager</option>
<option value="Owner/Proprietor">Owner/Proprietor</option>
<option value="Supervisor">Supervisor</option>
<option value="Vice President">Vice President</option>
<option value="Committee Member">Committee Member</option>
<option value="Society Member">Society Member</option>
<option value="Trustee">Trustee</option>
<option value="Secretary">Secretary</option>
<option value="Partner">Partner</option>
<option value="HR Manager">HR Manager</option>
<option value="HR Executive">HR Executive</option>
<option value="Admin">Admin</option>
 <option value="Principal">Principal</option>
<option value="Regional Director">Regional Director</option>
<option value="Regional Manager">Regional Manager</option>
</select>
<label class="mdl-textfield__label input_btm_line" for="gq_txtdesignation" style="color:rgba(0,0,0,0.7) !important;top: 0;"></label>
</div>
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label popup_input_div" style="padding-bottom: 0">
<select class="mdl-textfield__input input_us_style" style="font-size: 14px !important;" id="gq_txtno_of_employees" name="txtno_of_employees" required="1">
<option value="">-- Select No. of Employees --</option>
<option value="Less than 50
                                                ">Less than 50</option>
<option value="50-100">50-100</option>
<option value="100-500">100-500</option>
<option value="500-1000">500-1000</option>
<option value="More than 1000">More than 1000</option>
</select>
<label class="mdl-textfield__label input_btm_line" for="txtprefer_time_to_call" style="color:rgba(0,0,0,0.7) !important;top: 0;"></label>
</div>
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label popup_input_div us_pad_bot0">
<select class="mdl-textfield__input input_us_style" style="font-size: 14px !important;" id="gq_txtno_of_users" name="txtno_of_users" required="1">
<option value="">-- Select No. of Software Users --</option>
<option value="Less than 5">Less than 5</option>
<option value="5 to 10">5 to 10</option>
<option value="10 to 30">10 to 30</option>
<option value="30 to 50">30 to 50</option>
<option value="More than 50">More than 50</option>
</select>
<label class="mdl-textfield__label input_btm_line" for="txtprefer_time_to_call" style="color:rgba(0,0,0,0.7) !important;top: 0;"></label>
</div>
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label popup_input_div us_pad_bot0">
<select class="mdl-textfield__input input_us_style" style="font-size: 14px !important;" id="txtprefer_time_to_call" name="txtprefer_time_to_call" required="1">
<option value="">-- Select Preferred Time To Call --</option>
<option value="All Day">All Day</option>
<option value="Morning">Morning</option>
<option value="Noon">Noon</option>
<option value="Evening">Evening</option>
</select>
<label class="mdl-textfield__label input_btm_line" for="txtprefer_time_to_call" style="color:rgba(0,0,0,0.7) !important;top: 0;"></label>
</div>
<div class="getQuote_btn_div">
<button class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-button--colored btn-block us_subbtn_styl" type="submit" id="submit_btn3">SUBMIT</button>
</div>
</form>
</fieldset>


<fieldset class="cfieldset gq_cfieldset" id="fieldsetfourth">
<form class="regform" id="getquote_form4" style="text-align: center;">
<input type="hidden" name="clid" id="clid">
<p class="us_touch_shortly">Lastly, a few more details to help us serve you better</p>
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label popup_input_div us_submit_bot" style="padding-bottom: 0">
<select class="mdl-textfield__input input_us_style" style="font-size: 14px !important;" id="gq_txtdeployment" name="txtdeployment" required="1">
<option value="">-- Select Deployment --</option>
<option value="Cloud Based">Cloud Based</option>
<option value="On Premises">On Premises</option>
<option value="Hybrid">Hybrid</option>
<option value="Any">Any</option>
</select>
<label class="mdl-textfield__label input_btm_line" for="gq_txtdeployment" style="color:rgba(0,0,0,0.7) !important;top: 0"></label>
</div>
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label popup_input_div us_pad_bot0">
<input class="mdl-textfield__input input_us_style" id="gq_txtbudget" type="text" pattern="^[a-zA-Z0-9].*" placeholder="Budget *" value="" name="txtbudget" required="1">
<label class="mdl-textfield__label input_btm_line" for="gq_txtbudget" style="color:rgba(0,0,0,0.7) !important;"></label>
</div>
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label popup_input_div us_pad_bot0">
<input class="mdl-textfield__input input_us_style" id="gq_txtcurrent_software" type="text" placeholder="Current software*" pattern="^[a-zA-Z0-9].*" value="" name="txtcurrent_software" required="1">
<label class="mdl-textfield__label input_btm_line" for="gq_txtcurrent_software" style="color:rgba(0,0,0,0.7) !important;"></label>
</div>
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label popup_input_div us_pad_bot0 us_submit_bot">
<input type="text" class="mdl-textfield__input input_us_style" required="1" id="txtreason_to_change" placeholder="Reason to Changes*" name="txtreason_to_change" value="" pattern="^[a-zA-Z0-9].*" required="1">
<label class="mdl-textfield__label input_btm_line" for="txtreason_to_change" style="color:rgba(0,0,0,0.7) !important;"></label>
</div>
<div class="getQuote_btn_div">
<button class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-button--colored btn-block us_subbtn_styl" type="submit" id="submit_btn4">SUBMIT</button>
</div>
</form>
</fieldset>

</div>
</div>
</div>
<div class="mdl-cell mdl-cell--12-col us_secure_msg">
<img class="lazyload us_secure_img" data-sizes="auto" data-src="https://www.softwaresuggest.com/img/shield.png">
<p class="secured_p_msg">Trusted by more than 5 Million users across the globe.</p>
</div>
<div class="mdl-cell mdl-cell--12-col term_div_get">
<div class="mdl-textfield mdl-js-textfield form_tos_div">
<span class="tos_span_form">By submitting, you agree to our <a href="https://www.softwaresuggest.com/tos" target="_blank">Terms of Use</a> and <a href="https://www.softwaresuggest.com/privacy" target="_blank">Privacy Policy</a>.</span>
</div>
</div>
</div>
</div>
</div>
</div><style type="text/css">
#requestDemo .tos_span{
    display: block;
    text-align: center;
    font-size: 9px;
}
.terms_div_free{
    margin: 0 auto;
}
#requestDemo .iti {
  width: 100%;
}
@media only screen and (max-width: 480px){
    #first, #first_free, #fieldsettwo, #fieldsetform_free, #fieldsetfourth_free{
        padding: 0;
    }
    .mgetquote_headerslogan{
        text-align: center !important;
    }
    #requestDemo .popup_mobile_req_demo_p{
        text-align: center !important;
    }
    #requestDemo .tos_span{
        margin-bottom: 8px;
    }
}
@media only screen and (max-width: 350px){
    #requestDemo .mgetquote_headertitle{
        padding-bottom: 0;
        margin-bottom: 0;
    }
    #requestDemo .mgetquote_headerbrand{
        font-size: 12px;
    }
}
</style>
<div id="requestDemo" style="display: none;">
<div class="modal c_width_850px mobile_modal">
<div class="modal-dialog">
<div class="modal-content">
<a class="close"><i class="fa fa-times" aria-hidden="true"></i></a>

<div class="mdl-grid nopadding">
<div class="mdl-cell mdl-cell--2-col nomargin">
<div class="mgetquote_headerlogo mdl-cell--hide-phone">
<img class="lazyload" data-sizes="auto" data-src="https://d1myhw8pp24x4f.cloudfront.net/software_logo/1410243987_Sierra-tech-logo_mid.png" id="soft_img" height="70" width="70">
</div>
</div>
<div class="mdl-cell mdl-cell--10-col nomargin" style="position:relative;">
 <div class="mgetquote_headertitle popup_mobile_title_div">
<p class="mgetquote_headerbrand popup_mobile_title popup_mobile_req_demo_p" id="free_demo_title">Get Quote for Aarogya </p>
<p class="mgetquote_headerslogan popup_mobile_title">Hospital Management Software</p>
</div>
</div>
<hr style="background: #dedede;width: 100%;margin-top: 0px !important">
</div>


<div class="content" id="modal-get-quote-content-id_free" style="max-height: auto!important;display:none; height:auto !important;">
<div class="mdl-dialog__content">
<h6 class="thankyou_message_poup">Thank you for the enquiry.Our software experts will contact you in next 1 hour. </h6>
</div>
</div>

<div class="mdl-grid nopadding" id="content_form_free">
<div class="mdl-cell mdl-cell--12-col nomargin">
<div class="mgetquote_bodytitle">

Just one step away from selecting the right software
</div>
</div>
<div class="mdl-cell mdl-cell--6-col mdl-cell--6-col-desktop mdl-cell--4-col-tablet mdl-cell--hide-phone  nomargin">
<div class="mgetquote_bodyad">
<img id="req_demo_screen" class="lazyload" src="https://www.softwaresuggest.com/assets2/img/ajax-loader.gif" data-sizes="auto" data-src="">
</div>
</div>
<div class="mdl-cell mdl-cell--6-col mdl-cell--6-col-desktop mdl-cell--4-col-tablet nomargin popup_main_div_margin_left">
<div class="mgetquote_bodyform">
<fieldset id="first_free" class="cfieldset_free">
<form id="requestDemo_form1" style="text-align: center;">
<input type="hidden" name="sname" id="free_sname">
<input type="hidden" name="sid" id="free_sid">
<input type="hidden" name="cid" id="free_cid">
<input type="hidden" name="type" id="free_type">
<input type="hidden" name="category" id="free_category">
<input type="hidden" name="firstform" id="firstform" value="firstform">
<input type="hidden" name="source" id="request_demo" value="request_demo">
<input type="hidden" class="is_mobile_no_valid" name="ssleadpost[is_mobile_no_valid]">
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label popup_input_div">
<input class="mdl-textfield__input" id="free_txtname1" pattern="^[a-zA-Z0-9].*" type="text" value="" name="txtname" required="1">
<label class="mdl-textfield__label" for="txtname" style="color:rgba(0,0,0,0.7) !important;top:0;">Name *</label>
</div>
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label popup_input_div">
<input class="mdl-textfield__input" id="free_txtemail1" type="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,6}$" value="" name="txtemail" required="1">
<label class="mdl-textfield__label" for="txtemail" style="color:rgba(0,0,0,0.7) !important;top:0;">Business Email *</label>
</div>
<input class="mdl-textfield__input" id="requestdemo_countrycode" type="hidden" value="" name="countrycode">
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label popup_input_div">
<input onkeypress="return event.charCode >= 48 && event.charCode <= 57" class="mdl-textfield__input ssintlTelInput" pattern="^[0-9].*" id="free_txtphone1" type="tel" value="" name="txtphone" required="1" maxlength="12">
<label class="mdl-textfield__label" for="txtphone" style="color:rgba(0,0,0,0.7) !important; top:0;">Phone Number *</label>
<span id="requst_mblmsg"></span>
</div>

<div class="mdl-dialog__actions mdl-dialog__actions--full-width" style="vertical-align:middle;display: inline-block;">
<input type="submit" class="mdl-button mdl-js-button mdl-button--raised mdl-button--colored btn-block" style="height: 0%;text-align: center;" name="next" type="button" value="Submit" id="next_btn_free">
</div>

</form>
</fieldset>
<fieldset class="cfieldset_free" id="fieldsettwo">
<form class="regform" id="requestDemo_form2" style="text-align: center;">
<p class="h2_p" style="color:red; display: none;" id="msg2"></p>
<input type="hidden" name="sname" id="sname">
<input type="hidden" name="sid" id="sid">
<input type="hidden" name="cid" id="cid">
<input type="hidden" name="type" id="type">
<input type="hidden" name="txtname" id="txtname">
<input type="hidden" name="txtemail" id="txtemail">
<input type="hidden" name="txtphone" id="txtphone">
<input type="hidden" name="source" id="request_demo" value="request_demo">
<input type="hidden" name="category" id="category">
<input type="hidden" name="clid" id="clid">

<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label popup_input_div">
<input class="mdl-textfield__input" id="free_txtorganization" pattern="^[a-zA-Z0-9].*" type="text" value="" name="txtorganization" required="1">
<label class="mdl-textfield__label" for="txtname" style="color:rgba(0,0,0,0.7) !important;top:0;">Company Name *</label>
</div>
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label popup_input_div">

<select class="mdl-textfield__input" style="font-size: 14px !important;" id="free_txtindustry" name="txtindustry" required="1">
<option value="">-- Select Industry --</option>
<option value="Accounting / CPA">Accounting / CPA</option>
<option value="Advertising">Advertising</option>
<option value="Agriculture">Agriculture</option>
<option value="Architecture">Architecture</option>
<option value="Auto Dealership">Auto Dealership</option>
<option value="Banking">Banking</option>
<option value="Banking & Mortgage">Banking & Mortgage</option>
<option value="Construction / Contracting">Construction / Contracting</option>
<option value="Consulting">Consulting</option>
<option value="Distribution">Distribution</option>
<option value="Education">Education</option>
<option value="Engineering">Engineering</option>
<option value="Food / Beverage">Food / Beverage</option>
<option value="Government Agencies">Government Agencies</option>
<option value="Government Contractors">Government Contractors</option>
<option value="Healthcare / Social Services">Healthcare / Social Services</option>
<option value="Hospitality / Travel">Hospitality / Travel</option>
<option value="Insurance">Insurance</option>
<option value="Legal / Law Firm">Legal / Law Firm</option>
<option value="Marketing Services">Marketing Services</option>
<option value="Maintenance / Field Service">Maintenance / Field Service</option>
<option value="Manufacturing">Manufacturing</option>
<option value="Media & Newspaper">Media & Newspaper</option>
<option value="Nonprofit">Nonprofit</option>
<option value="Oil & Gas">Oil & Gas</option>
<option value="Pharmaceuticals">Pharmaceuticals</option>
<option value="Property Management">Property Management</option>
<option value="Real Estate">Real Estate</option>
<option value="Retail">Retail</option>
<option value="Software / Technology">Software / Technology</option>
<option value="Transportation">Transportation</option>
<option value="Telecommunications">Telecommunications</option>
<option value="Utilities">Utilities</option>
<option value="Other">Other</option>
</select>
<label class="mdl-textfield__label" for="txtindustry" style="color:rgba(0,0,0,0.7) !important;top: 0;">Industry *</label>
</div>
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label popup_input_div">
<input class="mdl-textfield__input" id="free_txtcity" type="text" value="" pattern="^[a-zA-Z0-9].*" name="txtcity" required="1">
<label class="mdl-textfield__label" for="txtcity" style="color:rgba(0,0,0,0.7) !important;">City*</label>
</div>
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label popup_input_div">
<textarea class="mdl-textfield__input" required="1" id="free_txtdescription" pattern="^[a-zA-Z0-9].*" name="txtdescription" value=""></textarea>
<label class="mdl-textfield__label" for="txtdescription" style="color:rgba(0,0,0,0.7) !important;">Requirements*</label>
</div>

<div class="mdl-dialog__actions mdl-dialog__actions--full-width" style="display: inline-block;">
<input class="mdl-button mdl-js-button mdl-button--raised mdl-button--colored btn-block" style="text-align: center;height: 0%" type="submit" value="Submit" id="submit_btn_free">
</div>
</form>
</fieldset>

<fieldset class="cfieldset_free" id="fieldsetform_free">
<form class="regform" id="requestDemo_form3" style="text-align: center;">
<input type="hidden" name="category" id="category">
<input type="hidden" name="clid" id="clid">
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label popup_input_div">

<select class="mdl-textfield__input" style="font-size: 14px !important;" id="free_txtdesignation" name="txtdesignation" required="1">
<option value="">-- Select Designation --</option>
<option value="Accountant">Accountant</option>
<option value="President">President</option>
<option value="Chairman">Chairman</option>
<option value="Consultant">Consultant</option>
<option value="CEO">CEO</option>
<option value="CXO">CXO</option>
<option value="Designer">Designer</option>
<option value="Developer">Developer</option>
<option value="Assistant Manager">Assistant Manager</option>
<option value="Doctor">Doctor</option>
<option value="Director">Director</option>
<option value="Engineer">Engineer</option>
<option value="Executive">Executive</option>
<option value="Freelancer">Freelancer</option>
<option value="General Manager">General Manager</option>
<option value="Clerk">Clerk</option>
<option value="Managing Director">Managing Director</option>
<option value="Chief Financial officer">Chief Financial officer</option>
<option value="IT Manager">IT Manager</option>
<option value="Manager">Manager</option>
<option value="Owner/Proprietor">Owner/Proprietor</option>
<option value="Supervisor">Supervisor</option>
<option value="Vice President">Vice President</option>
<option value="Committee Member">Committee Member</option>
<option value="Society Member">Society Member</option>
<option value="Trustee">Trustee</option>
<option value="Secretary">Secretary</option>
<option value="Partner">Partner</option>
<option value="HR Manager">HR Manager</option>
<option value="HR Executive">HR Executive</option>
<option value="Admin">Admin</option>
<option value="Principal">Principal</option>
<option value="Regional Director">Regional Director</option>
<option value="Regional Manager">Regional Manager</option>
</select>
<label class="mdl-textfield__label" for="txtdesignation" style="color:rgba(0,0,0,0.7) !important;top: 0;">Designation*</label>
</div>
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label popup_input_div">

<select class="mdl-textfield__input" style="font-size: 14px !important;" id="free_txtno_of_employees" name="txtno_of_employees" required="1">
<option value="">-- Select No. of Employees --</option>
<option value="Less than 50
                            ">Less than 50</option>
<option value="50-100">50-100</option>
<option value="100-500">100-500</option>
<option value="500-1000">500-1000</option>
<option value="More than 1000">More than 1000</option>
</select>
<label class="mdl-textfield__label" for="txtprefer_time_to_call" style="color:rgba(0,0,0,0.7) !important;top: 0;">Number of Employee in company *</label>
</div>
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label popup_input_div">
<select class="mdl-textfield__input" style="font-size: 14px !important;" id="free_txtno_of_users" name="txtno_of_users" required="1">
<option value="">-- Select No. of Software User --</option>
<option value="Less than 5">Less than 5</option>
<option value="5 to 10">5 to 10</option>
<option value="10 to 30">10 to 30</option>
<option value="30 to 50">30 to 50</option>
<option value="More than 50">More than 50</option>
</select>
<label class="mdl-textfield__label" for="txtprefer_time_to_call" style="color:rgba(0,0,0,0.7) !important;top: 0;">Number of Software User*</label>
</div>
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label popup_input_div">

<select class="mdl-textfield__input" style="font-size: 14px !important;" id="txtprefer_time_to_call" name="txtprefer_time_to_call" required="1">
<option value="">-- Select Preferred Time To Call --</option>
<option value="All Day">All Day</option>
<option value="Morning">Morning</option>
<option value="Noon">Noon</option>
<option value="Evening">Evening</option>
</select>
<label class="mdl-textfield__label" for="txtprefer_time_to_call" style="color:rgba(0,0,0,0.7) !important;top: 0;">Preferred time for us to call*</label>
</div>
<div class="mdl-dialog__actions mdl-dialog__actions--full-width" style="display: inline-block;">
 <input class="mdl-button mdl-js-button mdl-button--raised mdl-button--colored btn-block" style="text-align: center;height: 0%" type="submit" value="Submit" id="submit_btn3_free">
</div>
</form>
</fieldset>


<fieldset class="cfieldset_free" id="fieldsetfourth_free">
<form class="regform" id="requestDemo_form4" style="text-align: center;">
<input type="hidden" name="clid" id="clid">
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label popup_input_div">

<select class="mdl-textfield__input" style="font-size: 14px !important;" id="free_txtdeployment" name="txtdeployment" required="1">
<option value="">-- Select Deployment --</option>
<option value="Cloud Based">Cloud Based</option>
<option value="On Premises">On Premises</option>
<option value="Hybrid">Hybrid</option>
<option value="Any">Any</option>
</select>
<label class="mdl-textfield__label" for="txtdeployment" style="color:rgba(0,0,0,0.7) !important;top: 0;">Deployment*</label>
</div>
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label popup_input_div">
<input class="mdl-textfield__input" id="free_txtbudget" type="text" pattern="^[a-zA-Z0-9].*" value="" name="txtbudget" required="1">
<label class="mdl-textfield__label" for="txtbudget" style="color:rgba(0,0,0,0.7) !important;">Budget *</label>
</div>
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label popup_input_div">
<input class="mdl-textfield__input" id="free_txtcurrent_software" type="text" value="" name="txtcurrent_software" pattern="^[a-zA-Z0-9].*" required="1">
<label class="mdl-textfield__label" for="txtcurrent_software" style="color:rgba(0,0,0,0.7) !important;"> Current software*</label>
</div>
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label popup_input_div">
<input type="text" class="mdl-textfield__input" required="1" id="free_txtreason_to_change" name="txtreason_to_change" pattern="^[a-zA-Z0-9].*" value="" required="1">
<label class="mdl-textfield__label" for="txtreason_to_change" style="color:rgba(0,0,0,0.7) !important;">Reason to Changes*</label>
</div>
<div class="mdl-dialog__actions mdl-dialog__actions--full-width " style="display: inline-block;">
<input class="mdl-button mdl-js-button mdl-button--raised mdl-button--colored btn-block" style="text-align: center;height: 0%" type="submit" value="Submit" id="submit_btn4">
</div>
</form>
</fieldset>

</div>
</div>
<hr class="mdl-cell--hide-phone" style="background: #dedede;width: 100%;margin-top: 10px;">
</div>
<div class="mdl-grid nopadding home_getpopup_dis_block">
<div class="mdl-cell mdl-cell--12-col nomargin mdl-cell--hide-phone" style="margin: 15px;">
<img data-sizes="auto" data-src="https://www.softwaresuggest.com/assets2/img/happycustomer/popup_stripe.png?v=0.01" class="lazyload img_sati_part">
</div>
<div class="mdl-cell mdl-cell--12-col nomargin terms_div_free">
<span class="tos_span">By submitting, you agree to our <a href="https://www.softwaresuggest.com/tos" target="_blank">Terms of Use</a> and <a href="https://www.softwaresuggest.com/privacy" target="_blank">Privacy Policy</a>.</span>
</div>

</div>
</div>
</div>
</div>
</div>
<style type="text/css">
	.pop_marg_ask{
		margin-top: -25px;
	}
@media only screen and (max-width: 500px){
	.pop_marg_ask{
		margin-top: 0px;
	}
}

</style>
<div id="postRequest" style="display: none;">
<div class="modal postbyreq_modal padding_bot_0">
<h4 class="modal-title postreq_title" id="request_post_title" align="center">Post Buy Requirement</h4>
<hr>
<a class="close us_close_btn"><i class="material-icons close_btn_i">close</i></a>
<div class="content" id="modal-request-post-content-id" style="max-height: auto!important;display:none; height:auto !important;">
<div class="mdl-dialog__content">
<h6 class="thankyou_message_poup">Thank you for the enquiry.Our software experts will contact you in next 1 hour. </h6>
</div>
</div>
<div class="content responsive_popup_scroll">
<form id="requestPost_form">
<div class="mdl-dialog__content">
<input type="hidden" name="type" id="type_request_post">
<input type="hidden" name="category" id="category_request_post">
<div class="mdl-grid">
<div class="mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet">
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label post_responsive_name">
<input class="mdl-textfield__input" id="txtname_request_post" type="text" value="" name="txtname" pattern="^[a-zA-Z0-9].*" required="1">
<label class="mdl-textfield__label" for="txtname_request_post" style="color:rgba(0,0,0,0.7) !important;top:0">Name *</label>
</div>
 </div>
<div class="mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet">
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
<input class="mdl-textfield__input" id="txtemail_request_post" type="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,6}$" value="" name="txtemail" required="1">
<label class="mdl-textfield__label" for="txtemail_request_post" style="color:rgba(0,0,0,0.7) !important;top:0">Business Email *</label>
</div>
</div>


<div class="mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet post_marg_bot0"> <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label pop_marg_ask">
<input class="mdl-textfield__input" id="txtorganization_request_post1" type="text" value="" name="txtorganization" pattern="^[a-zA-Z0-9].*" required="1">
<label class="mdl-textfield__label" for="txtcity_request_post" style="color:rgba(0,0,0,0.7) !important;top:0">Company Name *</label>
</div>
</div>
<div class="mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet">
<input class="mdl-textfield__input" id="postbyrequest_countrycode" type="hidden" value="" name="countrycode">
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label pop_marg_ask">
<span class="clscountrycode">
<input onkeypress="return event.charCode >= 48 && event.charCode <= 57" class="mdl-textfield__input" id="txtphone_request_post" type="tel" value="" name="txtphone" required="1" maxlength="12">
</span>
<label class="mdl-textfield__label" for="txtphone_request_post" style="color:rgba(0,0,0,0.7) !important;top:0">Phone Number *</label>
<span id='requestPost_form_mblmsg'></span>
</div>
</div>
<div class="mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet post_marg_bot0">
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label pop_marg_ask">

<select class="mdl-textfield__input" style="font-size: 14px !important;padding-top: 13px;" id="txtdesignation_request_post" name="txtdesignation" required="1">
<option value="">-- Select Designation --</option>
<option value="Accountant">Accountant</option>
<option value="President">President</option>
<option value="Chairman">Chairman</option>
<option value="Consultant">Consultant</option>
<option value="CEO">CEO</option>
<option value="CXO">CXO</option>
<option value="Designer">Designer</option>
<option value="Developer">Developer</option>
<option value="Assistant Manager">Assistant Manager</option>
<option value="Doctor">Doctor</option>
 <option value="Director">Director</option>
<option value="Engineer">Engineer</option>
<option value="Executive">Executive</option>
<option value="Freelancer">Freelancer</option>
<option value="General Manager">General Manager</option>
<option value="Clerk">Clerk</option>
<option value="Managing Director">Managing Director</option>
<option value="Chief Financial officer">Chief Financial officer</option>
<option value="IT Manager">IT Manager</option>
<option value="Manager">Manager</option>
<option value="Owner/Proprietor">Owner/Proprietor</option>
<option value="Supervisor">Supervisor</option>
<option value="Vice President">Vice President</option>
<option value="Committee Member">Committee Member</option>
<option value="Society Member">Society Member</option>
<option value="Trustee">Trustee</option>
<option value="Secretary">Secretary</option>
<option value="Partner">Partner</option>
<option value="HR Manager">HR Manager</option>
<option value="HR Executive">HR Executive</option>
<option value="Admin">Admin</option>
<option value="Principal">Principal</option>
<option value="Regional Director">Regional Director</option>
<option value="Regional Manager">Regional Manager</option>
</select>
<label class="mdl-textfield__label" for="txtdesignation_request_post" style="color:rgba(0,0,0,0.7) !important;top:0">Designation *</label>
</div>
</div>
<div class="mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet post_marg_bot0">
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label pop_marg_ask">
<input class="mdl-textfield__input" id="txtcity_request_post" type="text" value="" name="txtcity" pattern="^[a-zA-Z0-9].*" required="1">
<label class="mdl-textfield__label" for="txtcity_request_post" style="color:rgba(0,0,0,0.7) !important;top:0">City *</label>
</div>
</div>
<div class="mdl-cell mdl-cell--12-col" style="margin-top: 0">
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
<textarea class="mdl-textfield__input" style="width:485px !important; " required="1" pattern="^[a-zA-Z0-9].*" id="txtdescription_request_post" name="txtdescription" value=""></textarea>
<label class="mdl-textfield__label" style="color:rgba(0,0,0,0.7) !important; width:485px;top:0" for="txtdescription_request_post">Requirements *</label>
</div>
</div>
</div>
</div>
<div class="mdl-dialog__actions mdl-dialog__actions--full-width" style="vertical-align:middle; padding:0px 45px 5px 65px !important;">

<input type="submit" id="submit_request_post" class="mdl-button mdl-js-button mdl-button--raised mdl-button--colored btn-block" style="text-align:center; " name="submit" value="Submit">
</div>
<div class="modal-footer home_getpopup_dis_block" style="border-top:none;padding:0px 10px 20px;margin-top:0px;">
<div class="row">
<div class="mdl-cell mdl-cell--12-col no-margin-right mdl-cell--hide-phone" style="width:100%;font-size:17px; color:rgba(0,0,0,0.7);" align="center"><b>We have helped <span style="color:#005a8c;text-decoration: underline;">464796 business</span> find the right Software</b></div>
<div class="mdl-cell mdl-cell--12-col">

</div>
</div>
</div>
</form>
</div>
</div>
</div>
<style type="text/css">
.model_new_top {
    top: 30%;
}

#askQuestion .terms_check_div {
    font-size: 9px;
    text-align: center;
    margin: 0 auto;
}
#askQuestion .requirement_div{
	margin-top: 0;
}
#askQuestion .terms_check_label {
    margin-top: -34px;
    display: flex;
    align-items: center;
    margin-bottom: 10px;
}
#askQuestion .pricing_pop_title {
    margin: 0;
}

#askQuestion .mdl-dialog__content {
    padding: 0!important;
}
#askQuestion .iti {
  width: 100%;
}

@media only screen and (max-width: 480px) {
    #askQuestion .popup_new_terms_div {
        margin-bottom: 24px;
    }
    #askQuestion .terms_check_div {
        margin-bottom: 24px;
    }
    #askQuestion .terms_check_label {
        display: block;
        margin-bottom: 0;
    }
}

@media only screen and (max-width: 350px) {
    #askQuestion .model_new_top {
        top: 31%;
        padding: 0;
    }
    #askQuestion .us_close_btn {
        top: 0 !important;
        right: 3px !important;
    }
    #askQuestion hr {
        margin: 0 !important;
    }
    #askQuestion .modal .content {
        padding: 0;
    }
    #askQuestion .pricing_pop_title {
        font-size: 12px !important;
    }
}
</style>
<div id="askQuestion" class="" style="display:none;">
<div class="modal res_pri_popup pricing_pop_div model_new_top">
<h4 class="modal-title pricing_pop_title" id="ask_question_title" align="center">Get Quote</h4>
<hr>
<a class="close us_close_btn"><i class="material-icons close_btn_i">close</i></a>
<div class="content" id="modal-ask-question-content-id" style="max-height: auto!important;display:none; height:auto !important;">
<div class="mdl-dialog__content">
<h6 class="thankyou_message_poup">
Thank you for the enquiry.Our software experts will contact you in next 1 hour. 
</h6>
</div>
</div>
<div class="content responsive_popup_scroll">
<form id="askque_form">
<div class="mdl-dialog__content">
<input type="hidden" name="sname" id="sname_ask">
<input type="hidden" name="sid" id="sid_ask">
<input type="hidden" name="cid" id="cid_ask">
<input type="hidden" name="type" id="type_ask">
<input type="hidden" name="category" id="category_ask">
<input type="hidden" class="is_mobile_no_valid" name="ssleadpost[is_mobile_no_valid]">
<div class="mdl-grid">
<div class="mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet">
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label pricing_pop_width">
<input class="mdl-textfield__input" id="txtname_ask_question" pattern="^[a-zA-Z0-9].*" type="text" value="" name="txtname" required="1">
<label class="mdl-textfield__label" for="txtname_ask_question" style="color:rgba(0,0,0,0.7) !important;top:0">Name *</label>
</div>
</div>
<div class="mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet">
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label pricing_pop_width">
<input class="mdl-textfield__input" id="txtemail_ask_question" type="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,6}$" value="" name="txtemail" required="1">
<label class="mdl-textfield__label" for="txtemail_ask_question" style="color:rgba(0,0,0,0.7) !important;top:0">Business Email *</label>
</div>
</div>


<div class="mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet post_marg_bot0">
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label pop_marg_ask">
<input class="mdl-textfield__input" id="txtorganization_ask_question" type="text" value="" name="txtorganization" pattern="^[a-zA-Z0-9].*" required="1">
<label class="mdl-textfield__label" for="txtcity_request_post" style="color:rgba(0,0,0,0.7) !important;top:0">Company Name *</label>
</div>
</div>
<input class="" id="ask_question_countrycode" type="hidden" value="" name="countrycode">
<div class="mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet">
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label pricing_pop_width pop_marg_ask">
<input onkeypress="return event.charCode >= 48 && event.charCode <= 57" class="mdl-textfield__input ssintlTelInput" id="txtphone_ask_question" type="tel" value="" name="txtphone" required="1" maxlength="12">
<label class="mdl-textfield__label" for="txtphone_ask_question" style="color:rgba(0,0,0,0.7) !important;top:0">Phone Number *</label>
<span id="ask_question_mblmsg"></span>
</div>
</div>
<div class="mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet">
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label pricing_pop_width pop_marg_ask">

<select class="mdl-textfield__input" style="font-size: 14px !important;padding-top: 4px;" id="txtdesignation_ask_question" name="txtdesignation" required="1">
<option value="">-- Select Designation --</option>
<option value="Accountant">Accountant</option>
<option value="President">President</option>
<option value="Chairman">Chairman</option>
<option value="Consultant">Consultant</option>
<option value="CEO">CEO</option>
<option value="CXO">CXO</option>
<option value="Designer">Designer</option>
<option value="Developer">Developer</option>
<option value="Assistant Manager">Assistant Manager</option>
<option value="Doctor">Doctor</option>
<option value="Director">Director</option>
<option value="Engineer">Engineer</option>
<option value="Executive">Executive</option>
<option value="Freelancer">Freelancer</option>
<option value="General Manager">General Manager</option>
<option value="Clerk">Clerk</option>
<option value="Managing Director">Managing Director</option>
<option value="Chief Financial officer">Chief Financial officer</option>
<option value="IT Manager">IT Manager</option>
 <option value="Manager">Manager</option>
<option value="Owner/Proprietor">Owner/Proprietor</option>
<option value="Supervisor">Supervisor</option>
<option value="Vice President">Vice President</option>
<option value="Committee Member">Committee Member</option>
<option value="Society Member">Society Member</option>
<option value="Trustee">Trustee</option>
<option value="Secretary">Secretary</option>
<option value="Partner">Partner</option>
<option value="HR Manager">HR Manager</option>
<option value="HR Executive">HR Executive</option>
<option value="Admin">Admin</option>
<option value="Principal">Principal</option>
<option value="Regional Director">Regional Director</option>
<option value="Regional Manager">Regional Manager</option>
</select>
<label class="mdl-textfield__label" for="txtdesignation_ask_question" style="color:rgba(0,0,0,0.7) !important;top:0">Designation *</label>
</div>
</div>
<div class="mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet">
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label pricing_pop_width pop_marg_ask">
<input class="mdl-textfield__input" id="txtcity_ask_question" type="text" pattern="^[a-zA-Z0-9].*" value="" name="txtcity" required="1">
<label class="mdl-textfield__label" for="txtcity_ask_question" style="color:rgba(0,0,0,0.7) !important;top:0">City *</label>
</div>
</div>
<div class="mdl-cell mdl-cell--12-col requirement_div">
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label pricing_pop_width">
<textarea class="mdl-textfield__input" required="1" id="txtdescription_ask_question" pattern="^[a-zA-Z0-9].*" name="txtdescription" value=""></textarea>
<label class="mdl-textfield__label" style="color:rgba(0,0,0,0.7) !important;top:0" for="txtdescription_ask_question">Requirements *</label>
</div>
</div>
</div>
</div>
<div class="mdl-dialog__actions mdl-dialog__actions--full-width pricing_pop_btn_padding" style="vertical-align:middle;">

<input type="submit" id="ask_question_submit" class="mdl-button mdl-js-button mdl-button--raised mdl-button--colored btn-block" style="text-align:center;color: white !important; " name="submit" value="Submit">
</div>
<div class="modal-footer home_getpopup_dis_block" style="border-top:none;margin-top:0px;">
<div class="row">
<div class="mdl-cell mdl-cell--12-col no-margin-right mdl-cell--hide-phone" style="width:100%;font-size:17px; color:rgba(0,0,0,0.7);" align="center"><b>Trusted By <span style="color:#005a8c;text-decoration: underline;">464,796 </span> Happy & Satisfied Businesses</b></div>
<div class="mdl-cell mdl-cell--12-col">

</div>
</div>
</div>
<div class="mdl-cell mdl-cell--12-col terms_check_div">

<span class="tos_span">By submitting, you agree to our <a href="https://www.softwaresuggest.com/tos" target="_blank">Terms of Use</a> and <a href="https://www.softwaresuggest.com/privacy" target="_blank">Privacy Policy</a>.</span>
</div>
</form>
</div>
</div>
</div>
<style type="text/css">
.model_new_top{
	top: 0;
}
.mdl-textfield {
	width: 100%;
}
#pricingPopup .pricing_popup_requirement{
	width: 100%;
    margin-top: -30px;
}
#pricingPopup .pricing_popup_city{
    margin-top: -15px;
}
#pricingPopup .terms_check_div{
    padding-left: 20px;
    font-size: 9px;
    margin: 0;
    text-align: center;
}
#pricingPopup .terms_check_label{
    margin-top: -34px;
    display: flex;
    align-items: center;
    margin-bottom: 10px;
}
#pricingPopup .iti {
  width: 100%;
}
@media only screen and (max-width: 480px){
	.model_new_top{
		top: 30%;
		height: inherit;
	}
	#pricingPopup .terms_check_div {
	    margin-bottom: 24px;
	}
	#pricingPopup .terms_check_label{
	    display: block;
	    margin-bottom: 0;
	}
}
@media only screen and (max-width: 375px){
	.model_new_top{
		top: 30%;
		height: 600px;
	}
}
@media only screen and (max-width: 350px){
    #pricingPopup .model_new_top {
	    top: 31%;
	    padding: 0;
	}
	#pricingPopup .us_close_btn{
		top: 0 !important;
    	right: 3px !important;
	}
    #pricingPopup hr{
    	margin: 0 !important;
    }
    #pricingPopup .modal .content{
    	padding: 0;
    }
    #pricingPopup .pricing_pop_title{
        font-size: 12px !important;
    }
}
@media only screen and (max-width: 320px){
	#pricingPopup .model_new_top {
	    top: 34%;
	    padding: 0;
	    height: 500px;
	}
}
</style>
<div id="pricingPopup" class="" style="display:none;">
<div class="modal res_pri_popup pricing_pop_div model_new_top">
<h4 id="title_s_pricing" class="pricing_pop_title" align="center">Pricing</h4>
<hr>
<a class="close us_close_btn"><i class="material-icons close_btn_i">close</i></a>
<div class="content" id="modal-pricing-content-id" style="display:none;">
<div class="mdl-dialog__content">
<h6 class="thankyou_message_poup">Thank you for the enquiry.Our software experts will contact you in next 1 hour. </h6>
</div>
</div>
<div class="content responsive_popup_scroll">
<form id="pricing_popup_form">
<div class="mdl-dialog__content">
<input type="hidden" name="sname" id="sname_s_pricing">
<input type="hidden" name="sid" id="sid_s_pricing">
<input type="hidden" name="cid" id="cid_s_pricing">
<input type="hidden" name="type" id="type_s_pricing">
<input type="hidden" name="category" id="category_s_pricing">
<input type="hidden" class="is_mobile_no_valid" name="ssleadpost[is_mobile_no_valid]">
<div class="mdl-grid">
<div class="mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet">
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label pricing_pop_width pop_marg_ask">
<input class="mdl-textfield__input" id="pricing_popup_txtname" type="text" pattern="^[a-zA-Z0-9].*" value="" name="txtname" required="1">
<label class="mdl-textfield__label" for="pricing_popup_txtname" style="color:rgba(0,0,0,0.7) !important;top:0">Name *</label>
</div>
</div>
<div class="mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet">
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label pricing_pop_width pop_marg_ask">
<input class="mdl-textfield__input" id="pricing_popup_txtemail" type="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,6}$" value="" name="txtemail" required="1">
<label class="mdl-textfield__label" for="pricing_popup_txtemail" style="color:rgba(0,0,0,0.7) !important;top:0">Business Email *</label>
</div>
</div>


<div class="mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet">
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label pricing_pop_width pop_marg_ask">
<input class="mdl-textfield__input" id="pricing_popup_txtorganization" type="text" pattern="^[a-zA-Z0-9].*" value="" name="txtorganization" required="1">
<label class="mdl-textfield__label" for="pricing_popup_txtcity" style="color:rgba(0,0,0,0.7) !important;top:0">Company Name *</label>
</div>
</div>
<div class="mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet">
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label pricing_pop_width pop_marg_ask">
<input class="" id="pricing_countrycode" type="hidden" value="" name="countrycode">
<input class="mdl-textfield__input ssintlTelInput" id="pricing_popup_txtphone" onkeypress="return event.charCode >= 48 && event.charCode <= 57" maxlength="12" type="tel" value="" name="txtphone" required="1">
<label class="mdl-textfield__label" for="pricing_popup_txtphone" style="color:rgba(0,0,0,0.7) !important;top:0">Phone Number *</label>
<span id='pricingPopup_mobile_valid'></span>
</div>
</div>
<div class="mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet">
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label pricing_pop_width pop_marg_ask">

<select class="mdl-textfield__input" style="font-size: 14px !important;padding-top: 13px;" id="pricing_popup_txtdesignation" name="txtdesignation" required="1">
<option value="">-- Select Designation --</option>
<option value="Accountant">Accountant</option>
<option value="President">President</option>
<option value="Chairman">Chairman</option>
<option value="Consultant">Consultant</option>
<option value="CEO">CEO</option>
<option value="CXO">CXO</option>
<option value="Designer">Designer</option>
<option value="Developer">Developer</option>
<option value="Assistant Manager">Assistant Manager</option>
<option value="Doctor">Doctor</option>
<option value="Director">Director</option>
<option value="Engineer">Engineer</option>
<option value="Executive">Executive</option>
<option value="Freelancer">Freelancer</option>
<option value="General Manager">General Manager</option>
<option value="Clerk">Clerk</option>
<option value="Managing Director">Managing Director</option>
<option value="Chief Financial officer">Chief Financial officer</option>
<option value="IT Manager">IT Manager</option>
<option value="Manager">Manager</option>
<option value="Owner/Proprietor">Owner/Proprietor</option>
<option value="Supervisor">Supervisor</option>
<option value="Vice President">Vice President</option>
<option value="Committee Member">Committee Member</option>
<option value="Society Member">Society Member</option>
<option value="Trustee">Trustee</option>
<option value="Secretary">Secretary</option>
<option value="Partner">Partner</option>
<option value="HR Manager">HR Manager</option>
<option value="HR Executive">HR Executive</option>
<option value="Admin">Admin</option>
<option value="Principal">Principal</option>
<option value="Regional Director">Regional Director</option>
<option value="Regional Manager">Regional Manager</option>
</select>
<label class="mdl-textfield__label" for="pricing_popup_txtdesignation" style="color:rgba(0,0,0,0.7) !important;top:0">Designation *</label>
</div>
</div>
<div class="mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet">
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label pricing_pop_width pop_marg_ask pricing_popup_city">
<input class="mdl-textfield__input" id="pricing_popup_txtcity" type="text" pattern="^[a-zA-Z0-9].*" value="" name="txtcity" required="1">
<label class="mdl-textfield__label" for="pricing_popup_txtcity" style="color:rgba(0,0,0,0.7) !important;top:0">City *</label>
</div>
</div>
<div class="mdl-cell mdl-cell--12-col">
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label pricing_pop_width pricing_popup_requirement">
<textarea class="mdl-textfield__input" required="1" id="pricing_popup_txtdescription" value="" pattern="^[a-zA-Z0-9].*" name="txtdescription"></textarea>
<label class="mdl-textfield__label" style="color:rgba(0,0,0,0.7) !important;" for="pricing_popup_txtdescription">Requirements *</label>
</div>
</div>
</div>
</div>
<div class="mdl-dialog__actions mdl-dialog__actions--full-width pricing_pop_btn_padding" style="vertical-align:middle;">

<input type="submit" id="pricing_popup_submit" class="mdl-button mdl-js-button mdl-button--raised mdl-button--colored btn-block" style="text-align:center; " name="submit" value="Submit">
</div>
<div class="modal-footer home_getpopup_dis_block" style="border-top:none;margin-top:0px;">
<div class="row">
<div class="mdl-cell mdl-cell--12-col no-margin-right mdl-cell--hide-phone" style="width:100%;font-size:17px; color:rgba(0,0,0,0.7);" align="center"><b>We have helped <span style="color:#005a8c;text-decoration: underline;">464796 business</span> find the right Software</b></div>
</div>
</div>
<div class="mdl-cell mdl-cell--12-col terms_check_div">
<span class="tos_span">By submitting, you agree to our <a href="https://www.softwaresuggest.com/tos" target="_blank">Terms of Use</a> and <a href="https://www.softwaresuggest.com/privacy" target="_blank">Privacy Policy</a>.</span>
</div>
</form>
</div>
</div>
</div><style type="text/css">
    #open_popup {
        display: none;
    }
    .open_popup_outer_div{
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        z-index: 1050;
        margin: 150px auto;
        padding: 20px;
        background: #fff;
        border: 1px solid #666;
        box-shadow: 0 0 50px rgba(0, 0, 0, .5);
        max-width: 450px;
        max-height: 400px;
        border-radius: 5px;
        overflow: hidden;
    }
    .login-main_heading{
        text-align: center;
        justify-content: center;
        padding-bottom: 15px;
    }
    .ss_logo_white{
        width:15%;
        margin-top:30px
    }
    .login-main{
        background-color: #FFFFFF;
        margin: 0 auto;
        height: 280px;
        width: 320px;
    }
    .login-main strong{
        color: black;
        display: flex;
        font-size: 18px;
        padding-top: 24px;
    }
    .login-main p{
        color: #857982;
        font-size: 16px;
        padding: 0 16px;
    }
    .btn-linkin{
        border-radius: 5px;
        background-color: #0077b5;
        display: block;
        justify-content: center;
        margin: 20px 16px;
        color: white;
        height: 50px;
        width: 280px;
        border-radius: 3px;
    }
    .btn-gmail{
        background-color: #D64829 !important;
    }
    .icon{
        font-size: 20px;
        justify-content: right;
        padding: 15px 15px;
        font-weight: 400;
    }
    .btn-linkin span{
        font-size: 17px;
        padding-top: 3px;
        padding-left: 20px;
        font-weight: 600;
        font-family: 'Graphik-Medium',sans-serif;
    }
    .modal-backdrop{
        overflow-y: hidden;
    }
</style>
<div class="" id="open_popup">
<div class="open_popup_outer_div">
<div class="mdl-grid mdl-grid--no-spacing">
<div class="mdl-cell mdl-cell--12-col mdl-cell--12-col-phone">
<div class="login-main">
<button type="button" class="close" aria-label="Close" id="login_close_btn">
<span aria-hidden="true">&times;</span>
</button>
<strong class="login-main_heading">Sign in Using Social media</strong>
<p>You can sign in using any of your social media accounts from below</p>
<a href="https://www.linkedin.com/oauth/v2/authorization?response_type=code&client_id=75na6qlyacqqxf&redirect_uri=http://www.softwaresuggest.com/social_login/LinkedIn/callback.php&state=72269143616&scope=r_emailaddress r_liteprofile w_member_social">
<div class="btn-lg btn-linkin">
<i class="fa fa-linkedin icon" aria-hidden="true">
<span>Login using Linkedin</span>
</i>
</div>
</a>
<a href="https://www.softwaresuggest.com/social_login/GooglePlus/index.php">
<div class="btn-lg btn-linkin btn-gmail  ">
<i class="fa fa-google icon g-signin2" aria-hidden="true" data-theme="dark">
<span>Login using Google</span>
</i>
</div>
</a>

</div>
</div>
</div>
</div>
<div class="modal-backdrop fade in" id="modal_backgroud"></div>
</div><style type="text/css">
  .popup_small_new{
    width: 100%;
    box-sizing: border-box;
  }
  .popup_small{
    position: relative;
    padding: 35px 15px;
    border-bottom-left-radius: 3px;
    border-bottom-right-radius: 3px;
  }
  .popup_small_field{
    color: #000000;
    border-radius: 3px;
    border: unset;
    padding-left: 10px;
    height: 35px;
    width: 100%;
    margin-right: 12px;
  }
  .popup_small_title{
    font-size: 18px;
    margin: 0;
    color: #ffffff;
  }
  .popup_small_quote{
    font-size: 14px;
    margin: 0 0 10px;
    color: #ffffff;
  }
  .popup_small_submit_btn{
    color: #ffffff;
    box-shadow: none;
    width: 175px;
  }
  .popup_small_close_div{
    position: absolute;
    right: 15px;
    top: 15px;
  }
  .popup_small_close{
    height: 23px;
    width: 23px;
    background-color: #2C76B5;
    border-radius: 3px;
    display: flex;
    font-size: 18px;
    justify-content: center;
    align-items: center;
    color: #ffffff;
    cursor: pointer;
  }
  .popup_small_form_field_div{
    display: flex;
  }
  .popup_small_new,
  .popup_small_form_two,
  .popup_small_form_three,
  .popup_small_form_four,
  .popup_small_message_div{
    display: none;
  }
  .popup_btn_disable, .popup_submit_btn_disable{
    pointer-events: none;
    user-select: none;
  }
  .popup_small_name{
    text-transform: uppercase;
    letter-spacing: 1.5px;
  }
  .popup_small_light_blue,.popup_small_light_blue:hover{
    background-color: #0088f6;
  }
  .popup_small_dark_blue,.popup_small_dark_blue:hover{
    background-color: #135893;    
  }
  .popup_small_btn_div{
    width: auto;
  }
  .popup_small_field_div{
    width: 100%;
    margin-right: 10px;
  }
  .popup_small_field_div textarea{
      padding-top: 10px;
  }
  .popup_small_new .intl-tel-input .selected-flag .iti-flag{
    left: 5px;
  }
  .popup_small_message_div .popup_small_quote{
    margin-bottom: 0;
  }
    .popup_small_new .popup_new_terms{
        color: #ffffff;
        margin-top: 6px;
    }
    .popup_small_new .popup_new_terms .mdl-checkbox.is-checked .mdl-checkbox__box-outline {
        border: 2px solid rgb(255, 255, 255);
    }
    .popup_small_new .popup_new_terms .mdl-checkbox__box-outline{
        border: 2px solid rgb(67, 152, 223);
    }
    .popup_small_new .mdl-checkbox.is-checked .mdl-checkbox__box-outline {
        border: 2px solid #ffffff;
    }
    .popup_small_new .mdl-checkbox.is-checked .mdl-checkbox__tick-outline {
        background: rgb(255, 255, 255)url(data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiI…lsZT0iZmlsbDojZmZmZmZmO2ZpbGwtb3BhY2l0eToxO3N0cm9rZTpub25lIiAvPgo8L3N2Zz4K);
    }
    .popup_small_new .mdl-button.mdl-button--disabled.mdl-button--disabled,
    .popup_small_new .mdl-button[disabled][disabled]{
        color: rgba(255, 255, 255, 0.64) !important;
        background-color: rgba(33, 150, 243, 0.45) !important;
    }
  .popup_new_terms a{
    color: #b1dcff;
  }
  .popup_new_terms {
    display: flex;
    align-items: center;
    font-size: 13px;
  }
  .popup_small_new .tos_span{
    display: block;
    margin-top: 8px;
    font-size: 9px;
    color: #ffffff;
    text-align: left;
  }
  .popup_small_new .tos_span a{
    color: #8ccaff;
  }
  .popup_small_new .iti {
      width: 100%;
  }
  @media only screen and (max-width: 768px) {
    .popup_small_quote {
        font-size: 11px;
    }
    .popup_small_title {
        font-size: 13px;
    }
    .popup_small_form_field_div{
      flex-direction: column;
    }
    .popup_small_field_div{
      margin: 8px 0;
    }
    .popup_small_btn_div{
      margin-top: 8px;
    }
    .popup_small_submit_btn{
      width: 100%;
    }
    .popup_small_quote{
      margin: 0;
    }
    .popup_small{
        padding: 15px;
        padding-bottom: 20px;
    }
    .popup_small_new .tos_span{
      text-align: center;
    }
  }
</style>
<div class="popup_small_new popup_small_dark_blue">
<div class="popup_small">
<div class="popup_small_close_div"><i class="material-icons popup_small_close">close</i></div>

<div class="popup_small_form_div">
<form class="popup_small_form_one">
<input type="hidden" name="ssleadpost[currentform]" value="firstform">
<input type="hidden" id="popup_countrycode" class="popup_countrycode" name="ssleadpost[countrycode]">
<input type="hidden" class="lead_id" name="ssleadpost[lead_id]">
<input type="hidden" class="is_mobile_no_valid" name="ssleadpost[is_mobile_no_valid]">
<div class="popup_small_quote_div">
<h6 class="popup_small_quote">Just one step away from selecting the right software | Trusted by more than 5 million users across the globe.</h6>
</div>
<div class="popup_small_form_field_div">
<div class="popup_small_field_div">
<input class="popup_small_field" type="text" name="ssleadpost[name]" placeholder="Name*" required="" pattern="^[a-zA-Z0-9].*" value="">
</div>
<div class="popup_small_field_div">
<input class="popup_small_field" type="email" name="ssleadpost[email]" placeholder="Email*" required="" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,6}$" value="">
</div>
<div class="popup_small_field_div">
<input class="popup_small_field ssintlTelInput" type="tel" name="ssleadpost[mobile]" placeholder="Contact" required="" maxlength="12" pattern="^[0-9].*" value="">
</div>
<div class="popup_small_btn_div">
<button class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect popup_small_submit_btn ripple_btn popup_small_light_blue" type="submit">Free Demo</button>
</div>
</div>
</form>
<form class="popup_small_form_two">
<input type="hidden" class="lead_id" name="ssleadpost[lead_id]">
<div class="popup_small_quote_div">
<h6 class="popup_small_quote">Help us better understand your business requirements | Trusted by more than 5 million users across the globe.</h6>
</div>
<div class="popup_small_form_field_div">
<div class="popup_small_field_div">
<input class="popup_small_field" pattern="^[a-zA-Z0-9].*" type="text" placeholder="Company Name *" name="ssleadpost[company]" required="" value="">
</div>
<div class="popup_small_field_div">
<select class="popup_small_field" name="ssleadpost[industry]" required="">
<option value="">-- Industry --</option>
<option value="Accounting / CPA">Accounting / CPA</option>
<option value="Advertising">Advertising</option>
<option value="Agriculture">Agriculture</option>
<option value="Architecture">Architecture</option>
<option value="Auto Dealership">Auto Dealership</option>
<option value="Banking">Banking</option>
<option value="Banking & Mortgage">Banking & Mortgage</option>
<option value="Construction / Contracting">Construction / Contracting</option>
<option value="Consulting">Consulting</option>
<option value="Distribution">Distribution</option>
<option value="Education">Education</option>
<option value="Engineering">Engineering</option>
<option value="Food / Beverage">Food / Beverage</option>
<option value="Government Agencies">Government Agencies</option>
<option value="Government Contractors">Government Contractors</option>
<option value="Healthcare / Social Services">Healthcare / Social Services</option>
<option value="Hospitality / Travel">Hospitality / Travel</option>
<option value="Insurance">Insurance</option>
<option value="Legal / Law Firm">Legal / Law Firm</option>
<option value="Marketing Services">Marketing Services</option>
<option value="Maintenance / Field Service">Maintenance / Field Service</option>
<option value="Manufacturing">Manufacturing</option>
<option value="Media & Newspaper">Media & Newspaper</option>
<option value="Nonprofit">Nonprofit</option>
<option value="Oil & Gas">Oil & Gas</option>
<option value="Pharmaceuticals">Pharmaceuticals</option>
<option value="Property Management">Property Management</option>
<option value="Real Estate">Real Estate</option>
<option value="Retail">Retail</option>
<option value="Software / Technology">Software / Technology</option>
<option value="Transportation">Transportation</option>
<option value="Telecommunications">Telecommunications</option>
<option value="Utilities">Utilities</option>
<option value="Other">Other</option>
</select>
</div>
<div class="popup_small_field_div">
<input class="popup_small_field" type="text" pattern="^[a-zA-Z0-9].*" placeholder="City*" name="ssleadpost[city]" required="" value="">
</div>
<div class="popup_small_field_div">
<textarea class="popup_small_field" required="" placeholder="Requirements*" pattern="^[a-zA-Z0-9].*" name="ssleadpost[description]"></textarea>
</div>
<div class="popup_small_btn_div">
<button class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect popup_small_submit_btn popup_small_light_blue" type="submit">Submit</button>
</div>
</div>
</form>
<form class="popup_small_form_three">
<input type="hidden" class="lead_id" name="ssleadpost[lead_id]">
<div class="popup_small_quote_div">
<h6 class="popup_small_quote">A little more about the business & preferred time of the call | Trusted by more than 5 million users across the globe.</h6>
</div>
<div class="popup_small_form_field_div">
<div class="popup_small_field_div">
<select class="popup_small_field" name="ssleadpost[designation]" required="">
<option value="">-- Designation --</option>
<option value="Accountant">Accountant</option>
<option value="President">President</option>
<option value="Chairman">Chairman</option>
<option value="Consultant">Consultant</option>
<option value="CEO">CEO</option>
<option value="CXO">CXO</option>
<option value="Designer">Designer</option>
<option value="Developer">Developer</option>
<option value="Assistant Manager">Assistant Manager</option>
<option value="Doctor">Doctor</option>
<option value="Director">Director</option>
<option value="Engineer">Engineer</option>
<option value="Executive">Executive</option>
<option value="Freelancer">Freelancer</option>
<option value="General Manager">General Manager</option>
<option value="Clerk">Clerk</option>
<option value="Managing Director">Managing Director</option>
<option value="Chief Financial officer">Chief Financial officer</option>
<option value="IT Manager">IT Manager</option>
<option value="Manager">Manager</option>
<option value="Owner/Proprietor">Owner/Proprietor</option>
<option value="Supervisor">Supervisor</option>
<option value="Vice President">Vice President</option>
<option value="Committee Member">Committee Member</option>
<option value="Society Member">Society Member</option>
<option value="Trustee">Trustee</option>
<option value="Secretary">Secretary</option>
<option value="Partner">Partner</option>
<option value="HR Manager">HR Manager</option>
<option value="HR Executive">HR Executive</option>
<option value="Admin">Admin</option>
<option value="Principal">Principal</option>
<option value="Regional Director">Regional Director</option>
<option value="Regional Manager">Regional Manager</option>
</select>
</div>
<div class="popup_small_field_div">
<select class="popup_small_field" name="ssleadpost[no_of_employees]" required="">
<option value="">-- No. of Employees --</option>
<option value="Less than 50">Less than 50</option>
<option value="50-100">50-100</option>
<option value="100-500">100-500</option>
<option value="500-1000">500-1000</option>
<option value="More than 1000">More than 1000</option>
</select>
</div>
<div class="popup_small_field_div">
<select class="popup_small_field" name="ssleadpost[no_of_users]" required="">
<option value="">-- No. of Software Users --</option>
<option value="Less than 5">Less than 5</option>
<option value="5 to 10">5 to 10</option>
<option value="10 to 30">10 to 30</option>
<option value="30 to 50">30 to 50</option>
<option value="More than 50">More than 50</option>
</select>
</div>
<div class="popup_small_field_div">
<select class="popup_small_field" name="ssleadpost[prefer_time_to_call]" required="">
<option value="">-- Preferred Time To Call --</option>
<option value="All Day">All Day</option>
<option value="Morning">Morning</option>
<option value="Noon">Noon</option>
<option value="Evening">Evening</option>
</select>
</div>
<div class="popup_small_btn_div">
<button class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect popup_small_submit_btn popup_small_light_blue" type="submit">Submit</button>
</div>
</div>
</form>
<form class="popup_small_form_four">
<input type="hidden" class="lead_id" name="ssleadpost[lead_id]">
<div class="popup_small_quote_div">
 <h6 class="popup_small_quote">Lastly, a few more details to help us serve you better | Trusted by more than 5 million users across the globe.</h6>
</div>
<div class="popup_small_form_field_div">
<div class="popup_small_field_div">
<select class="popup_small_field" name="ssleadpost[deployment]" required="">
<option value="">-- Deployment --</option>
<option value="Cloud Based">Cloud Based</option>
<option value="On Premises">On Premises</option>
<option value="Hybrid">Hybrid</option>
<option value="Any">Any</option>
</select>
</div>
<div class="popup_small_field_div">
<input class="popup_small_field" type="text" pattern="^[a-zA-Z0-9].*" placeholder="Budget *" name="ssleadpost[budget]" required="" value="">
</div>
<div class="popup_small_field_div">
<input class="popup_small_field" type="text" placeholder="Current software*" pattern="^[a-zA-Z0-9].*" name="ssleadpost[other_software]" required="" value="">
</div>
<div class="popup_small_field_div">
<input type="text" class="popup_small_field" required="" placeholder="Reason to Changes*" name="ssleadpost[reason_to_change]" pattern="^[a-zA-Z0-9].*" required="" value="">
</div>
<div class="popup_small_btn_div">
<button class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect popup_small_submit_btn popup_small_light_blue" type="submit">Submit</button>
</div>
</div>
</form>
<div class="popup_small_message_div">
<h6 class="popup_small_quote">Thank you for the enquiry. One of our software analysts will contact you in next 1 hour.</h6>
</div>
<span class="tos_span">By submitting, you agree to our <a href="https://www.softwaresuggest.com/tos" target="_blank">Terms of Use</a> and <a href="https://www.softwaresuggest.com/privacy" target="_blank">Privacy Policy</a></span>
</div>
</div>
</div>
<style type="text/css">
#ouibounce-modal form {
	margin: 8px 0;
}
#ouibounce-modal .modal {
	height: unset;
	position: relative;
	top: 60px;
	padding: 20px !important;
}
#ouibounce-modal .modal-footer {
	position: unset;
}
#ouibounce-modal .mdl-textfield {
	width: 100%;
	padding: 16px 0 0!important;
}
#ouibounce-modal .ss_popup_modal_div {
    max-width: 550px;
}
.intl-tel-input.separate-dial-code.allow-dropdown.iti-sdc-3 .selected-flag {
	text-align: left;
}
.intl-tel-input.separate-dial-code .selected-dial-code {
	padding-left: 40px;
}
.intl-tel-input .selected-flag .iti-arrow {
	right: 0;
}
#ouibounce-modal form input[type=text] {
	border-bottom: 1px solid #bdbdbd !important;
	font-size: 14px;
}
#ouibounce-modal form input {
	padding: 5px 12px !important;
}
#ouibounce-modal form input#txtphone_request_demo {
	padding-left: 84px !important;
}
.modal .us_touch_shortly {
	font-size: 13.5px;
}
#ouibounce-modal .mdl-dialog__content {
	padding: 0 !important;
}
.submit-btn {
	width: 100%;
}
#ouibounce-modal .modal-footer {
	padding: 0 !important;
	border: none;
}
#form-grid {
	padding: 0
}
.modal .us_touch_shortly {

}
#ouibounce-modal form p {
	text-align: center;
    font-size: 13.5px;
    color: #000;
    margin: 0;
    padding: 0;
    opacity: 1;
}
#ouibounce-modal .exit_title {
    margin: 0 0 16px;
    text-align: center;
    line-height: 32px;
    padding: 0 25px;
    font-size: 20px;
    text-transform: capitalize;
    font-weight: 500;
}
#ouibounce-modal hr {
	margin: 6px 0 !important;
}
#ouibounce-modal .form-submit-message {
	background: #d1ebff;
    width: 452px;
    margin: 0 auto;
    padding: 22px 26px!important;
    font-size: 18px!important;
    border: 1px solid #a9c5da;
    height: 8em;
}
#ouibounce-modal .form-submit-message h4 {
	line-height: 1.5;
	font-size: 17px;
    margin: 24px 0 16px;
}
#ouibounce-modal .submit-btn {
	padding: 0
}
#ouibounce-modal .secured_p_msg {
	margin: 0;
}
#ouibounce-modal .form_tos_div label {
    display: flex;
    align-items: center;
}
#exit_intent_submit.mdl-button[disabled][disabled] {
    color: rgba(0, 0, 0, .26) !important;
    cursor: default !important;
    background-color: rgba(0, 0, 0, .12) !important;
}
#ouibounce-modal .form_tos_div .mdl-checkbox__focus-helper,
#ouibounce-modal .form_tos_div .mdl-checkbox__box-outline {
    top: 0;
}
#ouibounce-modal .form_tos_div{
    text-align: center;
    padding-top: 0 !important;
}
#ouibounce-modal .tos_span_form{
    font-size: 9px;
    margin-bottom: 0;
}
.terms_div_exit{
    margin: 0 auto;
}
#ouibounce-modal #exit_intent_submit{
    margin-top: 24px;
}
#ouibounce-modal .iti {
    width: 100%;
}
</style>
<div id="ouibounce-modal" class="comeback active_popup" style=" display: none;">
<div class="modal modal_ct md_ctl c_width_850px exitmodal exit_modal_new_style ss_popup_modal_div">
<div>

<h4 class="exit_title" id="request_demo_title" align="center">Need personal assistance in software selection?</h4>
</div>
<hr>
<a id="exitintentpopup" class="close ct_close us_close_btn" onclick="document.getElementById('ouibounce-modal').style.display = 'none';"><i class="material-icons close_btn_i">close</i></a>
<div class="mdl-grid nopadding" id="content_form">

<div class="mdl-cell mdl-cell--12-col nomargin pop_center_new">
<div class="mgetquote_bodyform success_msg">

<div class="content ct_content">
<form id="exit_intent_form">
<div class="mdl-dialog__content mdl_dialog_ct_content dialog-content">
<input type="hidden" name="sname" id="sname_request_demo">
<input type="hidden" name="sid" id="sid_request_demo">
<input type="hidden" name="cid" id="cid_request_demo">
<input type="hidden" name="type" id="type_request_demo">
<input type="hidden" name="category" id="category_request_demo" value="">
<input type="hidden" name="exitform" id="exitform" value="firstform">
<input type="hidden" class="is_mobile_no_valid" name="ssleadpost[is_mobile_no_valid]">
<p class="us_touch_shortly">Your Data is secured with us</p>
<div class="" id="form-grid">
<div class="exit_marg_top0">
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label us_pad_bot0">
<input class="mdl-textfield__input new_getq input_us_style input_exit_style" id="txtname_request_demo" type="text" placeholder="Name *" value="" pattern="^[a-zA-Z0-9].*" name="txtname" required="1">
<label class="mdl-textfield__label lb_weight input_btm_line" for="txtname_request_demo"></label>
</div>
 </div>
<div class="exit_marg_top0">
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label us_pad_bot0">
<input class="mdl-textfield__input new_getq input_us_style input_exit_style" id="txtemail_request_demo" type="email" placeholder="Business Email *" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,6}$" value="" name="txtemail" required="1">
<label class="mdl-textfield__label lb_weight input_btm_line" for="txtemail_request_demo"></label>
</div>
</div>
<input class="mdl-textfield__input new_getq input_us_style input_exit_style" id="exit_intent_countrycode" type="hidden" value="" name="countrycode">
<div class="exit_marg_top0">
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label us_pad_bot0 flag_marg_new">
<input class="mdl-textfield__input new_getq pad_ct_left_number input_us_style input_exit_style ssintlTelInput" placeholder="Phone Number *" onkeypress="return event.charCode >= 48 && event.charCode <= 57" id="txtphone_request_demo" type="tel" value="" maxlength="12" name="txtphone" required="1">
<label class="mdl-textfield__label lb_weight input_btm_line" for="txtphone_request_demo"></label>
<span id="exitintent_mobile_msg"></span>
</div>
</div>

<div class="exit_marg_top0">
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label us_pad_bot0 us_pad_top0">
<input class="mdl-textfield__input new_getq input_us_style input_exit_style" placeholder="Company Name *" id="txtorganization_1" type="text" value="" pattern="^[a-zA-Z0-9].*" name="txtorganization" required="1">
<label class="mdl-textfield__label lb_weight input_btm_line" for="txtname_request_demo"></label>
</div>
</div>
</div>
</div>

<div class="mdl-dialog__actions mdl-dialog__actions--full-width submit-btn">

<input type="submit" id="exit_intent_submit" class="mdl-button mdl-js-button mdl-button--raised mdl-button--colored btn-block us_subbtn_styl" name="submit" value="Submit">
</div>
</form>
</div>
<div class="content ct_content">

<form id="exit_intent_form2" style="display: none;">
<div class="mdl-dialog__content mdl_dialog_ct_content dialog-content">
<input type="hidden" name="category" id="category">
<input type="hidden" name="clid" id="extlid" value="">
<input type="hidden" name="exitform" id="exitform" value="secondform">
<p class="us_touch_shortly">Help us better understand your business requirements</p>
<div class="" id="form-grid">
 <div class="exit_marg_top0">
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label us_pad_bot0">

<select class="mdl-textfield__input input_us_style input_exit_style" id="txtindustry" name="txtindustry" required="1">
<option value="">-- Select Industry --</option>
<option value="Accounting / CPA">Accounting / CPA</option>
<option value="Advertising">Advertising</option>
 <option value="Agriculture">Agriculture</option>
<option value="Architecture">Architecture</option>
<option value="Auto Dealership">Auto Dealership</option>
<option value="Banking">Banking</option>
<option value="Banking & Mortgage">Banking & Mortgage</option>
<option value="Construction / Contracting">Construction / Contracting</option>
<option value="Consulting">Consulting</option>
<option value="Distribution">Distribution</option>
<option value="Education">Education</option>
<option value="Engineering">Engineering</option>
<option value="Food / Beverage">Food / Beverage</option>
<option value="Government Agencies">Government Agencies</option>
<option value="Government Contractors">Government Contractors</option>
<option value="Healthcare / Social Services">Healthcare / Social Services</option>
<option value="Hospitality / Travel">Hospitality / Travel</option>
<option value="Insurance">Insurance</option>
<option value="Legal / Law Firm">Legal / Law Firm</option>
<option value="Marketing Services">Marketing Services</option>
<option value="Maintenance / Field Service">Maintenance / Field Service</option>
<option value="Manufacturing">Manufacturing</option>
<option value="Media & Newspaper">Media & Newspaper</option>
<option value="Nonprofit">Nonprofit</option>
<option value="Oil & Gas">Oil & Gas</option>
<option value="Pharmaceuticals">Pharmaceuticals</option>
<option value="Property Management">Property Management</option>
<option value="Real Estate">Real Estate</option>
 <option value="Retail">Retail</option>
<option value="Software / Technology">Software / Technology</option>
<option value="Transportation">Transportation</option>
<option value="Telecommunications">Telecommunications</option>
<option value="Utilities">Utilities</option>
<option value="Other">Other</option>
</select>
<label class="mdl-textfield__label lb_weight input_btm_line" for="txtindustry"></label>
</div>
</div>
<div class="exit_marg_top0">
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label us_pad_bot0">
<input class="mdl-textfield__input new_getq input_us_style input_exit_style" placeholder="City*" id="txtcity" type="text" pattern="^[a-zA-Z0-9].*" value="" name="txtcity" required="1">
<label class="mdl-textfield__label lb_weight input_btm_line" for="txtcity"></label>
</div>
</div>
<div class="exit_marg_top0">
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label us_pad_bot0">
<input class="mdl-textfield__input new_getq input_us_style input_exit_style" id="txtdescription" type="text" placeholder="Requirements *" pattern="^[a-zA-Z0-9].*" value="" name="txtdescription" required="1">
<label class="mdl-textfield__label lb_weight input_btm_line" for="txtdescription"></label>
</div>
</div>
<div class="exit_marg_top0">
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label us_pad_bot0">

<select class="mdl-textfield__input input_us_style input_exit_style" id="txtdesignation" name="txtdesignation" required="1">
<option value="">-- Select Designation --</option>
<option value="Accountant">Accountant</option>
<option value="President">President</option>
<option value="Chairman">Chairman</option>
<option value="Consultant">Consultant</option>
<option value="CEO">CEO</option>
<option value="CXO">CXO</option>
 <option value="Designer">Designer</option>
<option value="Developer">Developer</option>
<option value="Assistant Manager">Assistant Manager</option>
<option value="Doctor">Doctor</option>
<option value="Director">Director</option>
<option value="Engineer">Engineer</option>
<option value="Executive">Executive</option>
<option value="Freelancer">Freelancer</option>
<option value="General Manager">General Manager</option>
<option value="Clerk">Clerk</option>
<option value="Managing Director">Managing Director</option>
<option value="Chief Financial officer">Chief Financial officer</option>
<option value="IT Manager">IT Manager</option>
<option value="Manager">Manager</option>
<option value="Owner/Proprietor">Owner/Proprietor</option>
<option value="Supervisor">Supervisor</option>
<option value="Vice President">Vice President</option>
<option value="Committee Member">Committee Member</option>
<option value="Society Member">Society Member</option>
<option value="Trustee">Trustee</option>
<option value="Secretary">Secretary</option>
<option value="Partner">Partner</option>
<option value="HR Manager">HR Manager</option>
<option value="HR Executive">HR Executive</option>
<option value="Admin">Admin</option>
<option value="Principal">Principal</option>
<option value="Regional Director">Regional Director</option>
<option value="Regional Manager">Regional Manager</option>
 </select>
<label class="mdl-textfield__label lb_weight input_btm_line" for="txtdesignation"></label>
</div>
</div>
</div>
</div>
<div class="mdl-dialog__actions mdl-dialog__actions--full-width submit-btn">

<input type="submit" id="exit_intent_submit2" class="mdl-button mdl-js-button mdl-button--raised mdl-button--colored btn-block us_subbtn_styl" name="submit" value="Submit">
</div>
</form>
</div>
<div class="content ct_content">


<form id="exit_intent_form3" style="display: none;">
<div class="mdl-dialog__content mdl_dialog_ct_content dialog-content">
<input type="hidden" name="exitform" id="exitform" value="thirdform">
<input type="hidden" name="category" id="category">
<input type="hidden" name="clid" id="extlid" value="">
<p class="us_touch_shortly">A little more about the business & preferred time of the call</p>
<div class="" id="form-grid">
<div class="exit_marg_top0">
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label us_pad_bot0">

<select class="mdl-textfield__input input_us_style input_exit_style" id="txtno_of_employees" name="txtno_of_employees" required="1">
<option value="">-- Select No. of Employees --</option>
<option value="Less than 50
                                                    ">Less than 50</option>
<option value="50-100">50-100</option>
<option value="100-500">100-500</option>
<option value="500-1000">500-1000</option>
<option value="More than 1000">More than 1000</option>
</select>
<label class="mdl-textfield__label lb_weight input_btm_line" for="txtno_of_employees"></label>
</div>
</div>
<div class="exit_marg_top0">
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label popup_input_div us_pad_bot0">

<select class="mdl-textfield__input input_us_style input_exit_style" id="ei_txtno_of_users" name="txtno_of_users" required="1">
<option value="">-- Select No. of Software Users --</option>
<option value="Less than 5">Less than 5</option>
<option value="5 to 10">5 to 10</option>
<option value="10 to 30">10 to 30</option>
<option value="30 to 50">30 to 50</option>
<option value="More than 50">More than 50</option>
</select>
<label class="mdl-textfield__label input_btm_line" for="txtprefer_time_to_call"></label>
</div>
</div>
<div class="exit_marg_top0">
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label us_pad_bot0">
<select class="mdl-textfield__input input_us_style input_exit_style" id="txtprefer_time_to_call" name="txtprefer_time_to_call" required="1">
<option value="">-- Select Preferred Time To Call --</option>
<option value="All Day">All Day</option>
<option value="Morning">Morning</option>
<option value="Noon">Noon</option>
<option value="Evening">Evening</option>
</select>
<label class="mdl-textfield__label lb_weight input_btm_line" for="txtcompany_request_demo"></label>
</div>
</div>
<div class="exit_marg_top0">
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label us_pad_bot0">
<select class="mdl-textfield__input input_us_style input_exit_style" id="txtdeployment" name="txtdeployment" required="1">
<option value="">-- Select Deployment --</option>
<option value="Cloud Based">Cloud Based</option>
<option value="On Premises">On Premises</option>
<option value="Hybrid">Hybrid</option>
<option value="Any">Any</option>
</select>
<label class="mdl-textfield__label lb_weight input_btm_line" for="txtdeployment"></label>
</div>
</div>
</div>
</div>
<div class="mdl-dialog__actions mdl-dialog__actions--full-width submit-btn">

<input type="submit" id="exit_intent_submit3" class="mdl-button mdl-js-button mdl-button--raised mdl-button--colored btn-block us_subbtn_styl" name="submit" value="Submit">
</div>
</form>
</div>
<div class="content ct_content">


<form id="exit_intent_form4" style="display: none;">
<div class="mdl-dialog__content mdl_dialog_ct_content dialog-content">
<input type="hidden" name="exitform" id="exitform" value="fourthform">
<input type="hidden" name="category" id="category">
<input type="hidden" name="clid" id="extlid" value="">
<p class="us_touch_shortly">A little more about the business & preferred time of the call</p>
<div class="" id="form-grid">
<div class="exit_marg_top0">
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label us_pad_bot0">
<input class="mdl-textfield__input new_getq input_us_style input_exit_style" placeholder="Budget*" id="txtbudget" type="text" pattern="^[a-zA-Z0-9].*" value="" name="txtbudget" required="1">
<label class="mdl-textfield__label lb_weight input_btm_line" for="txtbudget"></label>
</div>
</div>
<div class="exit_marg_top0">
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label us_pad_bot0">
<input class="mdl-textfield__input new_getq input_us_style input_exit_style" placeholder="Current software*" id="txtcurrent_software" type="text" value="" name="txtcurrent_software" pattern="^[a-zA-Z0-9].*" required="1">
<label class="mdl-textfield__label lb_weight input_btm_line" for="txtcurrent_software"> </label>
</div>
</div>
<div class="exit_marg_top0">
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label us_pad_bot0 us_submit_bot">
<input class="mdl-textfield__input new_getq input_us_style input_exit_style" id="txtreason_to_change" type="text" placeholder="Reason to Changes *" pattern="^[a-zA-Z0-9].*" value="" name="txtreason_to_change" required="1">
<label class="mdl-textfield__label lb_weight input_btm_line" for="txtreason_to_change"></label>
</div>
</div>
</div>
</div>
<div class="mdl-dialog__actions mdl-dialog__actions--full-width submit-btn">

<input type="submit" id="exit_intent_submit4" class="mdl-button mdl-js-button mdl-button--raised mdl-button--colored btn-block us_subbtn_styl" name="submit" value="Submit">
</div>
 </form>

</div>
</div>
</div>
</div>

<div class="modal-footer dialog-footer">

<div class="mdl-cell mdl-cell--12-col mdl-cell--hide-phone us_secure_msg">
<img class="us_secure_img" src="https://www.softwaresuggest.com/img/shield.png">
<p class="secured_p_msg">Trusted by more than 5 Million global users</p>
</div>
<div class="mdl-cell mdl-cell--12-col terms_div_exit">
<div class="mdl-textfield mdl-js-textfield form_tos_div">
<span class="tos_span_form">By submitting, you agree to our <a href="https://www.softwaresuggest.com/tos" target="_blank">Terms of Use</a> and <a href="https://www.softwaresuggest.com/privacy" target="_blank">Privacy Policy</a>.</span>
</div>
</div>


</div>
</div>
</div>

<script type="text/javascript">
	var is_service_profile = '';
	var is_software_profile = '';
	var is_service_pages = '';
</script>

<script src="/js/detect.js"></script>
<script>
window.onload = function() {
	document.cookie = "ThirdPartyCookie=yes;";
	if (!(document.cookie.indexOf("ThirdPartyCookie=") > -1)) 
	{
        var OSname = window.ui.os;
        var browser_name = window.ui.browser;
        
        var all_data = "'"+browser_name+','+OSname+"'";
	    if(typeof OSname != 'undefined' || typeof browser_name != 'undefined')
	    {
	    	$.ajax({
		      type: "POST",
		      url: "/site/cookiedisable",
		      data: {data:all_data},
		      success: function(data){
		      }
		    });
	    }
	}
};
</script>

<style type="text/css">
	#gdpr_cookie{display:none;position:fixed;min-width:100%;height:auto;z-index:3;font-size:13px;line-height:20px;left:0;bottom:0;text-align:center}.gdpr_notice_container{padding:10px;text-align:center;width:700px;margin:0 auto;color:#fff;background-color:#005a8c;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;display:flex;justify-content:center;align-items:center;border-radius:3px}.gdpr_cookie_btn{text-align:left;min-width:70px}#gdpr_cookie .gdpr_cookie_btn a{background:#fff;padding:5px 10px;border-radius:3px;margin-left:10px}@media only screen and (max-width:1024px){.gdpr_notice_container{width:auto}}
	</style>
<div id="gdpr_cookie"><div class="gdpr_notice_container"><span>Cookies Policy | This website uses cookies to ensure you get the best experience on our website.</span><div class="gdpr_cookie_btn"><a href="javascript:void(0);" onclick="gdprClickCookie()" class="">GOT IT</a></div></div></div>
<script type="text/javascript">
	function gdprSetCookie(e,o,t){var i=new Date;i.setTime(i.getTime()+24*t*60*60*1e3);var n="expires="+i.toGMTString();document.cookie=e+"="+o+";"+n+";path=/"}function gdprGetCookie(e){for(var o=e+"=",t=decodeURIComponent(document.cookie).split(";"),i=0;i<t.length;i++){for(var n=t[i];" "==n.charAt(0);)n=n.substring(1);if(0==n.indexOf(o))return n.substring(o.length,n.length)}return""}function gdprCheckCookie(){""==gdprGetCookie("gdpr_cookie_status")&&(document.getElementById("gdpr_cookie").style.display="block")}function gdprClickCookie(){user=1,gdprSetCookie("gdpr_cookie_status",user,365),document.getElementById("gdpr_cookie").style.display="none"}gdprCheckCookie();
</script>

<script type="text/javascript">
	var baseUrl="https://www.softwaresuggest.com";
	var baseUrlTrue="https://www.softwaresuggest.com";
	var mobile_trigger_time=20000;
</script>
<input type="hidden" id="currentiphome" value="IN">
<input type="hidden" id="currentip" value="IN">


<script type="text/javascript">
	var lquote_head_gtag_script = "";
</script>

<script type="text/javascript">
    var popup_for = '';
</script>
<script type="text/javascript" src="https://www.softwaresuggest.com/assets2/js/custom/js_one.js?v=1.90"></script>
<script type="text/javascript" src="https://www.softwaresuggest.com/assets2/js/custom/common.js?v=2.28"></script>
<script type="text/javascript" src="https://www.softwaresuggest.com/assets2/js/custom/ga_event.js?v=0.55"></script>
<script>document.addEventListener("DOMContentLoaded", function(event) { 
        setTimeout(function(){
		          	(function(b,m,h,a,g){b[a]=b[a]||[];b[a].push({"gtm.start":new Date().getTime(),event:"gtm.js"});var k=m.getElementsByTagName(h)[0],e=m.createElement(h),c=a!="dataLayer"?"&l="+a:"";e.async=true;e.src="https://www.googletagmanager.com/gtm.js?id="+g+c;k.parentNode.insertBefore(e,k)})(window,document,"script","dataLayer","GTM-WQDBJVZ");
		          }, 3000);
    });
</script></div>
</body>
</html>